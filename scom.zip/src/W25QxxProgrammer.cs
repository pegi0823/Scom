using System;
using System.Globalization;
using System.IO.Ports;
using System.Text;
using System.Threading;

namespace Scom
{
    public sealed class W25QxxFlashInfo
    {
        public uint JedecId;
        public long Capacity;
        public string Model;
        public string Vendor;
    }

    public sealed class W25QxxException : Exception
    {
        public W25QxxException(string message) : base(message) { }
    }

    public sealed class W25QxxProgrammer : IDisposable
    {
        private SerialPort _port;
        private volatile bool _abort;

        public bool IsOpen
        {
            get { return _port != null && _port.IsOpen; }
        }

        public string PortName
        {
            get { return _port == null ? "" : _port.PortName; }
        }

        public void Open(string portName)
        {
            Close();

            SerialPort sp = new SerialPort(portName, 115200, Parity.None, 8, StopBits.One);
            sp.Handshake = Handshake.None;
            sp.ReadBufferSize = 65536;
            sp.WriteBufferSize = 65536;
            sp.ReadTimeout = 100;
            sp.WriteTimeout = 15000;
            try
            {
                sp.Open();
            }
            catch
            {
                try { sp.Dispose(); }
                catch { }
                throw;
            }
            try { sp.DiscardInBuffer(); }
            catch { }

            _port = sp;
            _abort = false;
        }

        public void Close()
        {
            SerialPort sp = _port;
            _port = null;

            if (sp != null)
            {
                try { if (sp.IsOpen) sp.Close(); }
                catch { }
                try { sp.Dispose(); }
                catch { }
            }
        }

        public void Abort()
        {
            _abort = true;
        }

        public void ResetAbort()
        {
            _abort = false;
        }

        public void ThrowIfAborted()
        {
            if (_abort) throw new OperationCanceledException("操作已取消。");
        }

        public void Dispose()
        {
            Close();
        }

        private void CheckAbort()
        {
            if (_abort) throw new OperationCanceledException("操作已取消。");
        }

        private SerialPort Port
        {
            get
            {
                SerialPort sp = _port;
                if (sp == null || !sp.IsOpen) throw new W25QxxException("串口未连接。");
                return sp;
            }
        }

        private void SendCommand(string cmd)
        {
            SerialPort sp = Port;
            try { sp.DiscardInBuffer(); }
            catch { }

            byte[] bytes = Encoding.ASCII.GetBytes(cmd + "\r\n");
            sp.Write(bytes, 0, bytes.Length);
        }

        private string ReadLine(int timeoutMs)
        {
            SerialPort sp = Port;
            StringBuilder sb = new StringBuilder();
            int oldTimeout = sp.ReadTimeout;
            sp.ReadTimeout = 50;
            DateTime deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);

            try
            {
                while (true)
                {
                    CheckAbort();
                    if (DateTime.UtcNow > deadline) return null;

                    int b;
                    try { b = sp.ReadByte(); }
                    catch (TimeoutException) { continue; }
                    if (b < 0) continue;

                    if (b == 10)
                    {
                        string s = sb.ToString();
                        if (s.EndsWith("\r")) s = s.Substring(0, s.Length - 1);
                        return s.Trim();
                    }

                    if (b != 13) sb.Append((char)b);
                    if (sb.Length > 8192) return sb.ToString().Trim();
                }
            }
            finally
            {
                try { if (sp.IsOpen) sp.ReadTimeout = oldTimeout; }
                catch { }
            }
        }

        private byte[] ReadRaw(int length, Action<int, int> progress)
        {
            SerialPort sp = Port;
            byte[] buffer = new byte[length];
            int offset = 0;
            int oldTimeout = sp.ReadTimeout;
            sp.ReadTimeout = 200;
            long timeoutMs = 5000L + (long)length * 2L;
            DateTime deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);

            try
            {
                while (offset < length)
                {
                    CheckAbort();
                    if (DateTime.UtcNow > deadline)
                    {
                        throw new W25QxxException(string.Format(
                            "读回数据超时：期望 {0} 字节，实际 {1} 字节。", length, offset));
                    }

                    int n;
                    try { n = sp.Read(buffer, offset, length - offset); }
                    catch (TimeoutException) { continue; }
                    if (n <= 0) continue;

                    offset += n;
                    if (progress != null) progress(offset, length);
                }
            }
            finally
            {
                try { if (sp.IsOpen) sp.ReadTimeout = oldTimeout; }
                catch { }
            }

            return buffer;
        }

        public W25QxxFlashInfo ReadId(Action<string> log)
        {
            return ReadIdCore(log, 3000);
        }

        public W25QxxFlashInfo TryReadId(int timeoutMs)
        {
            if (!IsOpen) throw new W25QxxException("串口未连接。");

            try
            {
                W25QxxFlashInfo info = ReadIdCore(null, timeoutMs);
                if (info == null || info.JedecId == 0) return null;
                return info;
            }
            catch (W25QxxException)
            {
                if (!IsOpen) throw;
                return null;
            }
        }

        private W25QxxFlashInfo ReadIdCore(Action<string> log, int timeoutMs)
        {
            SendCommand("I");
            string resp = ReadLine(timeoutMs);
            if (resp == null) throw new W25QxxException("读取 Flash ID 超时（无回复）。");
            if (!resp.StartsWith("OK,", StringComparison.Ordinal))
                throw new W25QxxException("读取 Flash ID 失败，设备回复：" + resp);

            string[] parts = resp.Split(new char[] { ',' }, 4);
            if (parts.Length < 4)
                throw new W25QxxException("Flash ID 响应格式错误：" + resp);

            string idText = parts[1].Trim();
            if (idText.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                idText = idText.Substring(2);

            uint jedec;
            if (!uint.TryParse(idText, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out jedec))
                throw new W25QxxException("Flash ID 格式错误：" + resp);

            long capacity;
            if (!long.TryParse(parts[2].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out capacity))
                throw new W25QxxException("Flash 容量格式错误：" + resp);

            string model = parts[3].Trim();
            byte vendorId = (byte)((jedec >> 16) & 0xFF);

            W25QxxFlashInfo info = new W25QxxFlashInfo();
            info.JedecId = jedec;
            info.Capacity = capacity;
            info.Model = model;
            info.Vendor = VendorName(vendorId);

            if (log != null)
            {
                log(string.Format(
                    "检测到 Flash：{0} {1}，ID=0x{2:X6}，容量={3:F2} MB",
                    info.Vendor, model, jedec, capacity / 1024.0 / 1024.0));
            }

            return info;
        }

        private static string VendorName(byte id)
        {
            switch (id)
            {
                case 0xEF: return "Winbond";
                case 0xC8: return "GigaDevice";
                case 0x85: return "PUYA";
                case 0x20: return "XMC/XTX";
                case 0xA1: return "复旦微";
                case 0x68: return "博雅";
                case 0x1C: return "EON";
                case 0xBF: return "SST";
                case 0x9D: return "ISSI";
                default: return string.Format("未知厂商(0x{0:X2})", id);
            }
        }

        public void EraseRange(uint startAddr, int length, Action<string> log)
        {
            if (length <= 0) return;

            long sectorStart = (long)startAddr & ~0xFFFL;
            long sectorEnd = ((long)startAddr + (long)length + 0xFFFL) & ~0xFFFL;
            long eraseLen = sectorEnd - sectorStart;
            long sectorCount = eraseLen / 4096L;

            if (log != null)
            {
                log(string.Format(
                    "开始擦除 0x{0:X} ~ 0x{1:X}（{2} 个扇区）",
                    sectorStart, sectorEnd, sectorCount));
            }

            SendCommand(string.Format(CultureInfo.InvariantCulture, "S {0} {1}", sectorStart, eraseLen));

            long timeout = Math.Max(5000L, sectorCount * 1000L + 5000L);
            if (timeout > 1800000L) timeout = 1800000L;

            string resp = ReadLine((int)timeout);
            if (resp == null) throw new W25QxxException("擦除超时。");
            if (!resp.StartsWith("OK,", StringComparison.Ordinal))
                throw new W25QxxException("擦除失败：" + resp);

            if (log != null) log("擦除完成。");
        }

        public void EraseChip(Action<string> log)
        {
            if (log != null) log("开始全片擦除（请耐心等待 25~200 秒）...");

            SendCommand("E");
            string resp = ReadLine(300000);
            if (resp == null) throw new W25QxxException("全片擦除超时（超过 5 分钟）。");
            if (!resp.StartsWith("OK,", StringComparison.Ordinal))
                throw new W25QxxException("全片擦除失败：" + resp);

            if (log != null) log("全片擦除完成。");
        }

        public void Write(uint startAddr, byte[] data, Action<int, int> progress, Action<string> log)
        {
            if (data == null || data.Length == 0) return;

            if (log != null)
            {
                log(string.Format("开始写入：地址=0x{0:X}，长度={1} 字节", startAddr, data.Length));
            }

            SendCommand(string.Format(CultureInfo.InvariantCulture, "W {0} {1}", startAddr, data.Length));

            string ready = ReadLine(3000);
            if (ready != "OK,READY")
            {
                throw new W25QxxException("设备未进入写入状态，回复：" +
                    (ready == null ? "(无回复)" : ready));
            }

            const int blockSize = 16384;
            int sent = 0;
            SerialPort sp = Port;

            while (sent < data.Length)
            {
                CheckAbort();
                int n = Math.Min(blockSize, data.Length - sent);
                sp.Write(data, sent, n);
                sent += n;
                if (progress != null) progress(sent, data.Length);
                Thread.Sleep(1);
            }

            long timeout = Math.Max(15000L, (long)data.Length / 512L * 200L);
            string done = ReadLine((int)timeout);
            if (done == null) throw new W25QxxException("写入完成等待超时。");
            if (!done.StartsWith("OK,WROTE", StringComparison.Ordinal))
                throw new W25QxxException("写入失败：" + done);

            string rest = done.Substring("OK,WROTE".Length).Trim();
            rest = rest.TrimStart(',', ' ');
            if (rest.Length > 0)
            {
                string[] tokens = rest.Split(new char[] { ' ', '\t', ',' }, StringSplitOptions.RemoveEmptyEntries);
                long wrote;
                if (tokens.Length > 0 &&
                    long.TryParse(tokens[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out wrote) &&
                    wrote != data.Length)
                {
                    throw new W25QxxException(string.Format(
                        "写入长度不匹配：期望 {0}，实际 {1}。", data.Length, wrote));
                }
            }

            if (log != null) log("写入完成。");
        }

        public byte[] Read(uint startAddr, int length, Action<int, int> progress, Action<string> log)
        {
            if (length <= 0) return new byte[0];

            if (log != null)
            {
                log(string.Format("开始读回：地址=0x{0:X}，长度={1} 字节", startAddr, length));
            }

            SendCommand(string.Format(CultureInfo.InvariantCulture, "R {0} {1}", startAddr, length));

            byte[] data = ReadRaw(length, progress);

            string done = ReadLine(5000);
            if (done == null) throw new W25QxxException("读回完成标志超时。");
            if (!done.StartsWith("OK,READ", StringComparison.Ordinal))
                throw new W25QxxException("读回完成标志异常：" + done);

            if (log != null) log("读回完成。");
            return data;
        }

        public int Verify(byte[] expected, uint startAddr, Action<int, int> progress, Action<string> log)
        {
            byte[] actual = Read(startAddr, expected.Length, progress, log);

            for (int i = 0; i < expected.Length; i++)
            {
                if (expected[i] != actual[i])
                {
                    if (log != null)
                    {
                        log(string.Format(
                            "校验失败：地址 0x{0:X}，期望 0x{1:X2}，实际 0x{2:X2}。",
                            (long)startAddr + i, expected[i], actual[i]));
                    }
                    return i;
                }
            }

            if (log != null) log("===== 校验通过 =====");
            return -1;
        }

        public bool ProgramFile(byte[] data, uint startAddr, bool doVerify,
            Action<string> log, Action<string, int, int> progress)
        {
            if (data == null || data.Length == 0)
                throw new W25QxxException("固件文件为空。");

            if (log != null) log(string.Format("文件大小 {0} 字节。", data.Length));

            W25QxxFlashInfo info = ReadId(log);
            if ((long)startAddr + (long)data.Length > info.Capacity)
            {
                throw new W25QxxException(string.Format(
                    "文件大小 ({0}B) 超出 Flash 容量 ({1}B)。", data.Length, info.Capacity));
            }

            if (progress != null) progress("擦除中...", 0, 0);
            EraseRange(startAddr, data.Length, log);

            if (progress != null) progress("写入中...", 0, data.Length);
            Write(startAddr, data,
                delegate(int cur, int total) { if (progress != null) progress("写入中...", cur, total); },
                log);

            if (doVerify)
            {
                if (progress != null) progress("读回校验中...", 0, data.Length);
                int bad = Verify(data, startAddr,
                    delegate(int cur, int total) { if (progress != null) progress("读回校验中...", cur, total); },
                    log);
                if (bad >= 0)
                {
                    throw new W25QxxException(string.Format(
                        "校验失败，第一个错误地址：0x{0:X}。", (long)startAddr + bad));
                }
            }

            if (progress != null) progress("烧写完成", 1, 1);
            if (log != null) log("===== 烧写成功 =====");
            return true;
        }
    }
}
