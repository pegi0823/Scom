﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace Scom
{
    public class MainForm : Form
    {
        private const int MaxHistoryBytes = 256 * 1024;
        private const int MaxDisplayChars = 900000;

        private readonly object _rxLock = new object();
        private readonly List<RxChunk> _rxHistory = new List<RxChunk>();
        private long _rxHistoryBytes;
        private long _rxTotal;
        private long _txTotal;
        private long _seq;
        private long _lastRenderedSeq;

        private SerialPort _port;
        private Encoding _encoding;
        private Decoder _decoder;

        private System.Windows.Forms.Timer _uiTimer;
        private System.Windows.Forms.Timer _repeatTimer;

        private ComboBox cboPort;
        private ComboBox cboBaud;
        private ComboBox cboDataBits;
        private ComboBox cboStopBits;
        private ComboBox cboParity;
        private ComboBox cboFlow;
        private ComboBox cboEncoding;
        private ComboBox cboLineEnd;

        private RoundButton btnOpen;
        private RoundButton btnRefresh;
        private RoundButton btnClearRx;
        private RoundButton btnSaveRx;
        private RoundButton btnResetCount;
        private RoundButton btnSend;
        private RoundButton btnClearTx;
        private RoundButton btnSendFile;
        private RoundButton btnW25;
        private RoundButton btnMin;
        private RoundButton btnMax;
        private RoundButton btnClose;

        private ToggleSwitch chkDtr;
        private ToggleSwitch chkRts;
        private ChipToggle chkHexDisplay;
        private ChipToggle chkTimestamp;
        private ChipToggle chkWrap;
        private ChipToggle chkAutoScroll;
        private ChipToggle chkPause;
        private ChipToggle chkHexSend;
        private ChipToggle chkNewLine;
        private ChipToggle chkRepeat;

        private NumericUpDown numInterval;
        private RichTextBox rtbRx;
        private RichTextBox rtbTx;
        private RoundPanel _rxFrame;
        private Label _lblRxEmpty;

        private PillLabel _connPill;
        private Label lblStatus;
        private Label lblRx;
        private Label lblTx;
        private Label lblVersion;

        private bool _dragging;
        private Point _dragOffset;
        private int _restoreWidth;
        private int _restoreHeight;

        public MainForm()
        {
            _encoding = Encoding.GetEncoding(936);
            _decoder = _encoding.GetDecoder();

            BuildUi();
            PopulateCombos();
            RefreshPorts();
            LoadSettings();
            BindEvents();

            _repeatTimer.Interval = (int)numInterval.Value;

            UpdateCounters();
            UpdateStatus();
            UpdateOpenButton();
        }

        private sealed class RxChunk
        {
            public long Seq;
            public DateTime Time;
            public byte[] Data;
        }

        private static readonly Color TextDark = UiTheme.Text;
        private static readonly Color TextMuted = UiTheme.TextSecondary;

        private void BuildUi()
        {
            SuspendLayout();

            Text = "SCOM 串口调试助手";
            Font = UiTheme.FontUI(9F);
            BackColor = UiTheme.Card;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(1000, 740);
            MinimumSize = new Size(960, 640);
            DoubleBuffered = true;
            KeyPreview = true;
            Padding = new Padding(4);

            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.Padding = new Padding(1);
            root.ColumnCount = 1;
            root.RowCount = 3;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 56F));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 32F));
            root.BackColor = UiTheme.Card;
            root.Margin = new Padding(0);

            root.Controls.Add(BuildTitleBar(), 0, 0);
            root.Controls.Add(BuildBody(), 0, 1);
            root.Controls.Add(BuildStatusBar(), 0, 2);

            Controls.Add(root);

            _uiTimer = new System.Windows.Forms.Timer();
            _uiTimer.Interval = 40;
            _uiTimer.Tick += UiTimer_Tick;

            _repeatTimer = new System.Windows.Forms.Timer();
            _repeatTimer.Interval = 1000;
            _repeatTimer.Tick += RepeatTimer_Tick;

            _uiTimer.Start();

            ResumeLayout(false);
            PerformLayout();
            UpdateWindowRegion();
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Padding target = WindowState == FormWindowState.Maximized
                ? Padding.Empty
                : new Padding(4);
            if (Padding != target) Padding = target;
            UpdateWindowRegion();
            UpdateMaxButtonGlyph();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (_restoreWidth >= MinimumSize.Width) Width = _restoreWidth;
            if (_restoreHeight >= MinimumSize.Height) Height = _restoreHeight;
            MaximizedBounds = Screen.FromControl(this).WorkingArea;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            ActiveControl = null;
            if (btnOpen != null) btnOpen.NotifyDefault(false);
            BeginInvoke((MethodInvoker)delegate
            {
                ActiveControl = null;
                if (btnOpen != null) btnOpen.NotifyDefault(false);
            });
            Invalidate(true);
            Update();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0.5F, 0.5F, Width - 1F, Height - 1F), 16F))
            using (Pen pen = new Pen(UiTheme.BorderStrong, 1F))
            {
                e.Graphics.DrawPath(pen, path);
            }
        }

        private void UpdateWindowRegion()
        {
            if (Width <= 0 || Height <= 0) return;

            if (WindowState == FormWindowState.Maximized)
            {
                Region old = Region;
                Region = null;
                if (old != null) old.Dispose();
                return;
            }

            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0, 0, Width, Height), 16F))
            {
                Region old = Region;
                Region = new Region(path);
                if (old != null) old.Dispose();
            }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style |= 0x00040000;
                return cp;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0083 && m.WParam != IntPtr.Zero)
            {
                m.Result = IntPtr.Zero;
                return;
            }

            base.WndProc(ref m);

            if (m.Msg != 0x0084) return;
            if (WindowState != FormWindowState.Normal) return;
            if ((int)m.Result != 1) return;

            int lp = m.LParam.ToInt32();
            int x = (short)(lp & 0xFFFF);
            int y = (short)((lp >> 16) & 0xFFFF);
            Point pt = PointToClient(new Point(x, y));

            const int grip = 3;
            bool left = pt.X <= grip;
            bool right = pt.X >= ClientSize.Width - grip;
            bool top = pt.Y <= grip;
            bool bottom = pt.Y >= ClientSize.Height - grip;

            if (left && top) m.Result = (IntPtr)13;
            else if (right && top) m.Result = (IntPtr)14;
            else if (left && bottom) m.Result = (IntPtr)16;
            else if (right && bottom) m.Result = (IntPtr)17;
            else if (left) m.Result = (IntPtr)10;
            else if (right) m.Result = (IntPtr)11;
            else if (top) m.Result = (IntPtr)12;
            else if (bottom) m.Result = (IntPtr)15;
        }

        private Control BuildTitleBar()
        {
            TableLayoutPanel bar = new TableLayoutPanel();
            bar.Dock = DockStyle.Fill;
            bar.ColumnCount = 1;
            bar.RowCount = 2;
            bar.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            bar.RowStyles.Add(new RowStyle(SizeType.Absolute, 1F));
            bar.BackColor = UiTheme.Card;
            bar.Margin = new Padding(0);
            bar.Padding = new Padding(0);

            TableLayoutPanel grid = new TableLayoutPanel();
            grid.Dock = DockStyle.Fill;
            grid.ColumnCount = 4;
            grid.RowCount = 1;
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            grid.BackColor = UiTheme.Card;
            grid.Margin = new Padding(0);
            grid.Padding = new Padding(14, 0, 8, 0);

            RoundPanel logo = new RoundPanel();
            logo.CornerRadius = 9;
            logo.BorderColor = Color.FromArgb(243, 199, 154);
            logo.BackColor = UiTheme.PrimarySoft;
            logo.Size = new Size(30, 30);
            logo.Margin = new Padding(0);
            logo.Anchor = AnchorStyles.Left;

            Label logoText = new Label();
            logoText.Text = "S";
            logoText.Dock = DockStyle.Fill;
            logoText.TextAlign = ContentAlignment.MiddleCenter;
            logoText.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            logoText.ForeColor = UiTheme.Accent;
            logoText.BackColor = Color.Transparent;
            logo.Controls.Add(logoText);
            grid.Controls.Add(logo, 0, 0);

            TableLayoutPanel stack = new TableLayoutPanel();
            stack.Dock = DockStyle.Fill;
            stack.ColumnCount = 1;
            stack.RowCount = 3;
            stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 22F));
            stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 16F));
            stack.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            stack.BackColor = UiTheme.Card;
            stack.Margin = new Padding(9, 0, 8, 0);
            stack.Padding = new Padding(0);

            Label title = new Label();
            title.Text = "SCOM 串口调试助手";
            title.Dock = DockStyle.Fill;
            title.TextAlign = ContentAlignment.BottomLeft;
            title.Font = UiTheme.FontUI(10F, FontStyle.Bold);
            title.ForeColor = UiTheme.Text;
            title.BackColor = Color.Transparent;
            title.Margin = new Padding(0);

            Label sub = new Label();
            sub.Text = "SERIAL DEBUGGER · v1.0";
            sub.Dock = DockStyle.Fill;
            sub.TextAlign = ContentAlignment.TopLeft;
            sub.Font = UiTheme.FontUI(7.5F);
            sub.ForeColor = UiTheme.TextTertiary;
            sub.BackColor = Color.Transparent;
            sub.Margin = new Padding(0);

            stack.Controls.Add(title, 0, 0);
            stack.Controls.Add(sub, 0, 1);
            grid.Controls.Add(stack, 1, 0);

            _connPill = new PillLabel();
            _connPill.Anchor = AnchorStyles.Right;
            _connPill.Margin = new Padding(0, 0, 10, 0);
            SetConnPill(false);
            grid.Controls.Add(_connPill, 2, 0);

            FlowLayoutPanel win = new FlowLayoutPanel();
            win.AutoSize = true;
            win.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            win.FlowDirection = FlowDirection.LeftToRight;
            win.WrapContents = false;
            win.Anchor = AnchorStyles.Right;
            win.BackColor = UiTheme.Card;
            win.Margin = new Padding(0);
            win.Padding = new Padding(0);

            btnMin = MakeWindowButton("—");
            btnMax = MakeWindowButton("□");
            btnClose = MakeWindowButton("×");
            win.Controls.Add(btnMin);
            win.Controls.Add(btnMax);
            win.Controls.Add(btnClose);
            grid.Controls.Add(win, 3, 0);

            Panel line = new Panel();
            line.Dock = DockStyle.Fill;
            line.BackColor = UiTheme.Border;
            line.Margin = new Padding(0);

            bar.Controls.Add(grid, 0, 0);
            bar.Controls.Add(line, 0, 1);

            AttachDrag(bar);
            AttachDrag(grid);
            AttachDrag(logo);
            AttachDrag(logoText);
            AttachDrag(stack);
            AttachDrag(title);
            AttachDrag(sub);
            bar.DoubleClick += delegate { ToggleMaximize(); };
            grid.DoubleClick += delegate { ToggleMaximize(); };
            title.DoubleClick += delegate { ToggleMaximize(); };
            sub.DoubleClick += delegate { ToggleMaximize(); };

            return bar;
        }

        private Control BuildBody()
        {
            TableLayoutPanel body = new TableLayoutPanel();
            body.Dock = DockStyle.Fill;
            body.ColumnCount = 2;
            body.RowCount = 1;
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 216F));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            body.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            body.BackColor = UiTheme.Card;
            body.Margin = new Padding(0);
            body.Padding = new Padding(0);

            body.Controls.Add(BuildRail(), 0, 0);
            body.Controls.Add(BuildMain(), 1, 0);
            return body;
        }

        private Control BuildRail()
        {
            Panel rail = new Panel();
            rail.Dock = DockStyle.Fill;
            rail.BackColor = UiTheme.Border;
            rail.Padding = new Padding(0, 0, 1, 0);
            rail.Margin = new Padding(0);

            Panel inner = new Panel();
            inner.Dock = DockStyle.Fill;
            inner.BackColor = UiTheme.PanelBg;
            inner.Margin = new Padding(0);
            rail.Controls.Add(inner);

            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 1;
            t.RowCount = 13;
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 22F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 54F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 54F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 54F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 54F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 46F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 19F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 42F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 38F));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            t.BackColor = UiTheme.PanelBg;
            t.Padding = new Padding(14, 12, 13, 12);
            t.Margin = new Padding(0);
            inner.Controls.Add(t);

            cboPort = MakeCombo(0, false);
            cboBaud = MakeCombo(0, true);
            cboDataBits = MakeCombo(0, false);
            cboStopBits = MakeCombo(0, false);
            cboParity = MakeCombo(0, false);
            cboFlow = MakeCombo(0, false);

            btnRefresh = MakeGhostButton("刷新", 44);
            btnRefresh.Height = 18;
            btnRefresh.CornerRadius = 6;
            btnRefresh.Font = UiTheme.FontUI(7.5F);
            btnRefresh.BackColor = UiTheme.PanelBg;
            btnRefresh.Margin = new Padding(0);

            t.Controls.Add(MakeRailLabel("连接参数"), 0, 0);
            t.Controls.Add(MakeFieldBlock("串口", cboPort, btnRefresh), 0, 1);
            t.Controls.Add(MakeFieldBlock("波特率", cboBaud, null), 0, 2);
            t.Controls.Add(MakePair(MakeFieldBlock("数据位", cboDataBits, null),
                                    MakeFieldBlock("停止位", cboStopBits, null)), 0, 3);
            t.Controls.Add(MakePair(MakeFieldBlock("校验位", cboParity, null),
                                    MakeFieldBlock("流控", cboFlow, null)), 0, 4);

            btnOpen = new RoundButton();
            btnOpen.Text = "打开串口";
            btnOpen.Dock = DockStyle.Fill;
            btnOpen.CornerRadius = 10;
            btnOpen.BackColor = UiTheme.Primary;
            btnOpen.ForeColor = Color.White;
            btnOpen.BorderColor = Color.Transparent;
            btnOpen.HoverColor = UiTheme.Accent;
            btnOpen.PressColor = UiTheme.Blend(UiTheme.Accent, Color.Black, 0.08);
            btnOpen.Font = UiTheme.FontUI(9F, FontStyle.Bold);
            btnOpen.Margin = new Padding(0, 6, 0, 4);
            t.Controls.Add(btnOpen, 0, 5);

            chkDtr = new ToggleSwitch();
            t.Controls.Add(MakeSwitchRow("DTR", chkDtr), 0, 6);
            chkRts = new ToggleSwitch();
            t.Controls.Add(MakeSwitchRow("RTS", chkRts), 0, 7);

            t.Controls.Add(MakeDivider(), 0, 8);
            t.Controls.Add(MakeRailLabel("烧写工具"), 0, 9);

            btnW25 = MakeGhostButton("W25Qxx 烧写", 0);
            btnW25.Dock = DockStyle.Fill;
            btnW25.CornerRadius = 9;
            btnW25.BackColor = UiTheme.Card;
            btnW25.ForeColor = UiTheme.Text;
            btnW25.BorderColor = UiTheme.BorderStrong;
            btnW25.HoverColor = UiTheme.InputBg;
            btnW25.Font = UiTheme.FontUI(8.5F);
            btnW25.Margin = new Padding(0, 4, 0, 4);
            t.Controls.Add(btnW25, 0, 10);

            Label hint = new Label();
            hint.Text = "SPI Flash 固件烧写";
            hint.Dock = DockStyle.Fill;
            hint.TextAlign = ContentAlignment.TopLeft;
            hint.Font = UiTheme.FontUI(7.5F);
            hint.ForeColor = UiTheme.TextTertiary;
            hint.BackColor = Color.Transparent;
            hint.Margin = new Padding(1, 0, 0, 0);
            t.Controls.Add(hint, 0, 11);

            Panel spacer = new Panel();
            spacer.Dock = DockStyle.Fill;
            spacer.BackColor = UiTheme.PanelBg;
            spacer.Margin = new Padding(0);
            t.Controls.Add(spacer, 0, 12);

            return rail;
        }

        private Control BuildMain()
        {
            TableLayoutPanel main = new TableLayoutPanel();
            main.Dock = DockStyle.Fill;
            main.ColumnCount = 1;
            main.RowCount = 3;
            main.RowStyles.Add(new RowStyle(SizeType.Absolute, 46F));
            main.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            main.RowStyles.Add(new RowStyle(SizeType.Absolute, 192F));
            main.BackColor = UiTheme.Card;
            main.Margin = new Padding(0);
            main.Padding = new Padding(0);

            main.Controls.Add(BuildToolbar(), 0, 0);
            main.Controls.Add(BuildLogArea(), 0, 1);
            main.Controls.Add(BuildSender(), 0, 2);
            return main;
        }

        private Control BuildToolbar()
        {
            TableLayoutPanel bar = new TableLayoutPanel();
            bar.Dock = DockStyle.Fill;
            bar.ColumnCount = 1;
            bar.RowCount = 2;
            bar.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            bar.RowStyles.Add(new RowStyle(SizeType.Absolute, 1F));
            bar.BackColor = UiTheme.Card;
            bar.Margin = new Padding(0);
            bar.Padding = new Padding(0);

            TableLayoutPanel content = new TableLayoutPanel();
            content.Dock = DockStyle.Fill;
            content.ColumnCount = 2;
            content.RowCount = 1;
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            content.BackColor = UiTheme.Card;
            content.Margin = new Padding(0);
            content.Padding = new Padding(14, 0, 12, 0);

            FlowLayoutPanel chips = new FlowLayoutPanel();
            chips.Dock = DockStyle.Fill;
            chips.FlowDirection = FlowDirection.LeftToRight;
            chips.WrapContents = false;
            chips.AutoScroll = false;
            chips.BackColor = UiTheme.Card;
            chips.Margin = new Padding(0);
            chips.Padding = new Padding(0);

            chkHexDisplay = MakeChip("HEX 显示", false);
            chkTimestamp = MakeChip("时间戳", false);
            chkWrap = MakeChip("自动换行", true);
            chkAutoScroll = MakeChip("自动滚动", true);
            chkPause = MakeChip("暂停显示", false);
            chips.Controls.Add(chkHexDisplay);
            chips.Controls.Add(chkTimestamp);
            chips.Controls.Add(chkWrap);
            chips.Controls.Add(chkAutoScroll);
            chips.Controls.Add(chkPause);
            content.Controls.Add(chips, 0, 0);

            FlowLayoutPanel tools = new FlowLayoutPanel();
            tools.AutoSize = true;
            tools.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            tools.FlowDirection = FlowDirection.LeftToRight;
            tools.WrapContents = false;
            tools.Anchor = AnchorStyles.Right;
            tools.BackColor = UiTheme.Card;
            tools.Margin = new Padding(0);
            tools.Padding = new Padding(0);

            Label encLabel = new Label();
            encLabel.Text = "编码";
            encLabel.AutoSize = true;
            encLabel.Font = UiTheme.FontUI(8F);
            encLabel.ForeColor = UiTheme.TextTertiary;
            encLabel.BackColor = Color.Transparent;
            encLabel.Margin = new Padding(0, 11, 5, 0);
            tools.Controls.Add(encLabel);

            cboEncoding = MakeCombo(70, false);
            cboEncoding.Margin = new Padding(0, 9, 12, 0);
            tools.Controls.Add(cboEncoding);

            btnClearRx = MakeGhostButton("清空", 54);
            btnClearRx.Margin = new Padding(0, 10, 6, 0);
            tools.Controls.Add(btnClearRx);

            btnSaveRx = MakeGhostButton("保存", 54);
            btnSaveRx.Margin = new Padding(0, 10, 6, 0);
            tools.Controls.Add(btnSaveRx);

            btnResetCount = MakeGhostButton("清零", 54);
            btnResetCount.Margin = new Padding(0, 10, 0, 0);
            tools.Controls.Add(btnResetCount);

            content.Controls.Add(tools, 1, 0);

            Panel line = new Panel();
            line.Dock = DockStyle.Fill;
            line.BackColor = UiTheme.Border;
            line.Margin = new Padding(0);

            bar.Controls.Add(content, 0, 0);
            bar.Controls.Add(line, 0, 1);
            return bar;
        }

        private Control BuildLogArea()
        {
            Panel area = new Panel();
            area.Dock = DockStyle.Fill;
            area.BackColor = UiTheme.Card;
            area.Padding = new Padding(14, 8, 14, 0);
            area.Margin = new Padding(0);

            _rxFrame = new RoundPanel();
            _rxFrame.Dock = DockStyle.Fill;
            _rxFrame.CornerRadius = 10;
            _rxFrame.BorderColor = UiTheme.Border;
            _rxFrame.BackColor = UiTheme.LogBg;
            _rxFrame.Padding = new Padding(9, 7, 9, 7);
            _rxFrame.Margin = new Padding(0);
            area.Controls.Add(_rxFrame);

            rtbRx = new RichTextBox();
            rtbRx.Dock = DockStyle.Fill;
            rtbRx.ReadOnly = true;
            rtbRx.BackColor = UiTheme.LogBg;
            rtbRx.ForeColor = UiTheme.Text;
            rtbRx.Font = UiTheme.FontMono(9.5F);
            rtbRx.BorderStyle = BorderStyle.None;
            rtbRx.WordWrap = true;
            rtbRx.ScrollBars = RichTextBoxScrollBars.Vertical;
            rtbRx.HideSelection = false;
            rtbRx.DetectUrls = false;
            rtbRx.MaxLength = int.MaxValue;
            rtbRx.Margin = new Padding(0);
            _rxFrame.Controls.Add(rtbRx);

            _lblRxEmpty = new Label();
            _lblRxEmpty.Text = "等待接收数据…";
            _lblRxEmpty.Dock = DockStyle.Fill;
            _lblRxEmpty.TextAlign = ContentAlignment.MiddleCenter;
            _lblRxEmpty.Font = UiTheme.FontUI(8.5F);
            _lblRxEmpty.ForeColor = UiTheme.TextTertiary;
            _lblRxEmpty.BackColor = UiTheme.LogBg;
            _lblRxEmpty.Margin = new Padding(0);
            _rxFrame.Controls.Add(_lblRxEmpty);
            _lblRxEmpty.BringToFront();

            rtbRx.TextChanged += delegate { UpdateEmptyState(); };

            return area;
        }

        private Control BuildSender()
        {
            TableLayoutPanel outer = new TableLayoutPanel();
            outer.Dock = DockStyle.Fill;
            outer.ColumnCount = 1;
            outer.RowCount = 2;
            outer.RowStyles.Add(new RowStyle(SizeType.Absolute, 1F));
            outer.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            outer.BackColor = UiTheme.Card;
            outer.Margin = new Padding(0);
            outer.Padding = new Padding(0);

            Panel line = new Panel();
            line.Dock = DockStyle.Fill;
            line.BackColor = UiTheme.Border;
            line.Margin = new Padding(0);
            outer.Controls.Add(line, 0, 0);

            TableLayoutPanel content = new TableLayoutPanel();
            content.Dock = DockStyle.Fill;
            content.ColumnCount = 1;
            content.RowCount = 3;
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 38F));
            content.BackColor = UiTheme.Card;
            content.Margin = new Padding(0);
            content.Padding = new Padding(14, 8, 14, 8);

            TableLayoutPanel header = new TableLayoutPanel();
            header.Dock = DockStyle.Fill;
            header.ColumnCount = 2;
            header.RowCount = 1;
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            header.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            header.BackColor = UiTheme.Card;
            header.Margin = new Padding(0);
            header.Padding = new Padding(0);

            Label title = new Label();
            title.Text = "发送数据";
            title.Dock = DockStyle.Fill;
            title.TextAlign = ContentAlignment.MiddleLeft;
            title.Font = UiTheme.FontUI(9F, FontStyle.Bold);
            title.ForeColor = UiTheme.Text;
            title.BackColor = Color.Transparent;
            title.Margin = new Padding(0);
            header.Controls.Add(title, 0, 0);

            FlowLayoutPanel headerTools = new FlowLayoutPanel();
            headerTools.AutoSize = true;
            headerTools.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            headerTools.FlowDirection = FlowDirection.LeftToRight;
            headerTools.WrapContents = false;
            headerTools.Anchor = AnchorStyles.Right;
            headerTools.BackColor = UiTheme.Card;
            headerTools.Margin = new Padding(0);
            headerTools.Padding = new Padding(0);

            chkHexSend = MakeChip("HEX 发送", false);
            chkNewLine = MakeChip("发送新行", false);
            chkHexSend.Margin = new Padding(0, 1, 6, 0);
            chkNewLine.Margin = new Padding(0, 1, 8, 0);
            headerTools.Controls.Add(chkHexSend);
            headerTools.Controls.Add(chkNewLine);

            cboLineEnd = MakeCombo(58, false);
            cboLineEnd.Margin = new Padding(0, 2, 0, 0);
            headerTools.Controls.Add(cboLineEnd);
            header.Controls.Add(headerTools, 1, 0);
            content.Controls.Add(header, 0, 0);

            RoundPanel inputFrame = new RoundPanel();
            inputFrame.Dock = DockStyle.Fill;
            inputFrame.CornerRadius = 10;
            inputFrame.BorderColor = UiTheme.Border;
            inputFrame.BackColor = UiTheme.InputBg;
            inputFrame.Padding = new Padding(9, 6, 9, 6);
            inputFrame.Margin = new Padding(0, 6, 0, 6);
            content.Controls.Add(inputFrame, 0, 1);

            rtbTx = new RichTextBox();
            rtbTx.Dock = DockStyle.Fill;
            rtbTx.BackColor = UiTheme.InputBg;
            rtbTx.ForeColor = UiTheme.Text;
            rtbTx.Font = UiTheme.FontMono(9.5F);
            rtbTx.BorderStyle = BorderStyle.None;
            rtbTx.WordWrap = true;
            rtbTx.ScrollBars = RichTextBoxScrollBars.Vertical;
            rtbTx.MaxLength = int.MaxValue;
            rtbTx.AcceptsTab = true;
            rtbTx.Margin = new Padding(0);
            inputFrame.Controls.Add(rtbTx);

            Label txHint = new Label();
            txHint.Text = "在此输入要发送的数据…";
            txHint.Dock = DockStyle.Fill;
            txHint.TextAlign = ContentAlignment.MiddleLeft;
            txHint.Font = UiTheme.FontUI(9F);
            txHint.ForeColor = UiTheme.TextTertiary;
            txHint.BackColor = UiTheme.InputBg;
            txHint.Margin = new Padding(0);
            txHint.Cursor = Cursors.IBeam;
            inputFrame.Controls.Add(txHint);
            txHint.BringToFront();

            EventHandler syncTxHint = delegate
            {
                txHint.Visible = rtbTx.TextLength == 0 && !rtbTx.Focused;
            };
            rtbTx.TextChanged += syncTxHint;
            txHint.MouseDown += delegate { rtbTx.Focus(); };

            rtbTx.Enter += delegate
            {
                inputFrame.BorderColor = Color.FromArgb(243, 199, 154);
                inputFrame.BackColor = UiTheme.Card;
                rtbTx.BackColor = UiTheme.Card;
                txHint.BackColor = UiTheme.Card;
                txHint.Visible = false;
            };
            rtbTx.Leave += delegate
            {
                inputFrame.BorderColor = UiTheme.Border;
                inputFrame.BackColor = UiTheme.InputBg;
                rtbTx.BackColor = UiTheme.InputBg;
                txHint.BackColor = UiTheme.InputBg;
                syncTxHint(null, EventArgs.Empty);
            };

            TableLayoutPanel footer = new TableLayoutPanel();
            footer.Dock = DockStyle.Fill;
            footer.ColumnCount = 3;
            footer.RowCount = 1;
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            footer.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            footer.BackColor = UiTheme.Card;
            footer.Margin = new Padding(0);
            footer.Padding = new Padding(0);

            FlowLayoutPanel left = new FlowLayoutPanel();
            left.AutoSize = true;
            left.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            left.FlowDirection = FlowDirection.LeftToRight;
            left.WrapContents = false;
            left.Anchor = AnchorStyles.Left;
            left.BackColor = UiTheme.Card;
            left.Margin = new Padding(0);
            left.Padding = new Padding(0);

            btnSendFile = MakeGhostButton("发送文件", 74);
            btnSendFile.Margin = new Padding(0, 5, 6, 0);
            left.Controls.Add(btnSendFile);

            btnClearTx = MakeGhostButton("清空", 54);
            btnClearTx.Margin = new Padding(0, 5, 12, 0);
            left.Controls.Add(btnClearTx);

            chkRepeat = MakeChip("定时发送", false);
            chkRepeat.Margin = new Padding(0, 5, 6, 0);
            left.Controls.Add(chkRepeat);

            numInterval = new NumericUpDown();
            numInterval.Minimum = 10;
            numInterval.Maximum = 600000;
            numInterval.Increment = 100;
            numInterval.Value = 1000;
            numInterval.Width = 66;
            numInterval.Font = UiTheme.FontMono(8F);
            numInterval.BorderStyle = BorderStyle.FixedSingle;
            numInterval.TextAlign = HorizontalAlignment.Center;
            numInterval.Margin = new Padding(0, 7, 4, 0);
            left.Controls.Add(numInterval);

            Label ms = new Label();
            ms.Text = "ms";
            ms.AutoSize = true;
            ms.Font = UiTheme.FontUI(8F);
            ms.ForeColor = UiTheme.TextTertiary;
            ms.BackColor = Color.Transparent;
            ms.Margin = new Padding(0, 10, 0, 0);
            left.Controls.Add(ms);
            footer.Controls.Add(left, 0, 0);

            Panel spacer = new Panel();
            spacer.Dock = DockStyle.Fill;
            spacer.BackColor = UiTheme.Card;
            spacer.Margin = new Padding(0);
            footer.Controls.Add(spacer, 1, 0);

            FlowLayoutPanel right = new FlowLayoutPanel();
            right.AutoSize = true;
            right.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            right.FlowDirection = FlowDirection.LeftToRight;
            right.WrapContents = false;
            right.Anchor = AnchorStyles.Right;
            right.BackColor = UiTheme.Card;
            right.Margin = new Padding(0);
            right.Padding = new Padding(0);

            Label hint = new Label();
            hint.Text = "Ctrl + Enter 快速发送";
            hint.AutoSize = true;
            hint.Font = UiTheme.FontUI(8F);
            hint.ForeColor = UiTheme.TextTertiary;
            hint.BackColor = Color.Transparent;
            hint.Margin = new Padding(0, 11, 10, 0);
            right.Controls.Add(hint);

            btnSend = new RoundButton();
            btnSend.Text = "发送";
            btnSend.Size = new Size(108, 34);
            btnSend.CornerRadius = 10;
            btnSend.BackColor = UiTheme.Primary;
            btnSend.ForeColor = Color.White;
            btnSend.BorderColor = Color.Transparent;
            btnSend.HoverColor = UiTheme.Accent;
            btnSend.PressColor = UiTheme.Blend(UiTheme.Accent, Color.Black, 0.08);
            btnSend.Font = UiTheme.FontUI(9F, FontStyle.Bold);
            btnSend.Margin = new Padding(0, 1, 0, 0);
            right.Controls.Add(btnSend);
            footer.Controls.Add(right, 2, 0);

            content.Controls.Add(footer, 0, 2);
            outer.Controls.Add(content, 0, 1);
            return outer;
        }

        private Control BuildStatusBar()
        {
            TableLayoutPanel bar = new TableLayoutPanel();
            bar.Dock = DockStyle.Fill;
            bar.ColumnCount = 1;
            bar.RowCount = 2;
            bar.RowStyles.Add(new RowStyle(SizeType.Absolute, 1F));
            bar.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            bar.BackColor = UiTheme.PanelBg;
            bar.Margin = new Padding(0);
            bar.Padding = new Padding(0);

            Panel line = new Panel();
            line.Dock = DockStyle.Fill;
            line.BackColor = UiTheme.Border;
            line.Margin = new Padding(0);
            bar.Controls.Add(line, 0, 0);

            TableLayoutPanel content = new TableLayoutPanel();
            content.Dock = DockStyle.Fill;
            content.ColumnCount = 2;
            content.RowCount = 1;
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            content.BackColor = UiTheme.PanelBg;
            content.Margin = new Padding(0);
            content.Padding = new Padding(14, 0, 12, 0);

            lblStatus = new Label();
            lblStatus.Text = "串口未打开 · 请选择端口";
            lblStatus.Dock = DockStyle.Fill;
            lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            lblStatus.Font = UiTheme.FontMono(8F);
            lblStatus.ForeColor = UiTheme.TextTertiary;
            lblStatus.BackColor = Color.Transparent;
            lblStatus.Margin = new Padding(0);
            content.Controls.Add(lblStatus, 0, 0);

            FlowLayoutPanel right = new FlowLayoutPanel();
            right.AutoSize = true;
            right.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            right.FlowDirection = FlowDirection.LeftToRight;
            right.WrapContents = false;
            right.Anchor = AnchorStyles.Right;
            right.BackColor = UiTheme.PanelBg;
            right.Margin = new Padding(0);
            right.Padding = new Padding(0);

            lblRx = MakeStatusLabel("RX 0 B");
            lblTx = MakeStatusLabel("TX 0 B");
            lblVersion = MakeStatusLabel("SCOM v1.0");
            lblTx.Margin = new Padding(0, 8, 14, 0);
            lblVersion.Margin = new Padding(0, 8, 0, 0);
            lblVersion.ForeColor = UiTheme.TextTertiary;
            right.Controls.Add(lblRx);
            right.Controls.Add(lblTx);
            right.Controls.Add(lblVersion);
            content.Controls.Add(right, 1, 0);

            bar.Controls.Add(content, 0, 1);
            return bar;
        }

        private static Label MakeStatusLabel(string text)
        {
            Label l = new Label();
            l.Text = text;
            l.AutoSize = true;
            l.Font = UiTheme.FontMono(8F);
            l.ForeColor = UiTheme.TextSecondary;
            l.BackColor = Color.Transparent;
            l.Margin = new Padding(0, 8, 14, 0);
            return l;
        }

        private static Label MakeRailLabel(string text)
        {
            Label l = new Label();
            l.Text = text;
            l.Dock = DockStyle.Fill;
            l.TextAlign = ContentAlignment.MiddleLeft;
            l.Font = UiTheme.FontUI(7.5F, FontStyle.Bold);
            l.ForeColor = UiTheme.TextTertiary;
            l.BackColor = Color.Transparent;
            l.Margin = new Padding(1, 2, 0, 2);
            return l;
        }

        private static TableLayoutPanel MakeFieldBlock(string labelText, Control control, Control trailing)
        {
            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 1;
            t.RowCount = 2;
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 18F));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            t.BackColor = UiTheme.PanelBg;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);

            if (trailing == null)
            {
                Label label = new Label();
                label.Text = labelText;
                label.Dock = DockStyle.Fill;
                label.TextAlign = ContentAlignment.MiddleLeft;
                label.Font = UiTheme.FontUI(8F);
                label.ForeColor = UiTheme.TextSecondary;
                label.BackColor = Color.Transparent;
                label.Margin = new Padding(0);
                t.Controls.Add(label, 0, 0);
            }
            else
            {
                TableLayoutPanel head = new TableLayoutPanel();
                head.Dock = DockStyle.Fill;
                head.ColumnCount = 2;
                head.RowCount = 1;
                head.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                head.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
                head.BackColor = UiTheme.PanelBg;
                head.Margin = new Padding(0);
                head.Padding = new Padding(0);

                Label label = new Label();
                label.Text = labelText;
                label.Dock = DockStyle.Fill;
                label.TextAlign = ContentAlignment.MiddleLeft;
                label.Font = UiTheme.FontUI(8F);
                label.ForeColor = UiTheme.TextSecondary;
                label.BackColor = Color.Transparent;
                label.Margin = new Padding(0);
                head.Controls.Add(label, 0, 0);

                trailing.Anchor = AnchorStyles.Right;
                head.Controls.Add(trailing, 1, 0);
                t.Controls.Add(head, 0, 0);
            }

            control.Dock = DockStyle.Top;
            control.Margin = new Padding(0);
            t.Controls.Add(control, 0, 1);
            return t;
        }

        private static TableLayoutPanel MakePair(Control left, Control right)
        {
            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 2;
            t.RowCount = 1;
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            t.BackColor = UiTheme.PanelBg;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);

            left.Dock = DockStyle.Fill;
            left.Margin = new Padding(0, 0, 4, 0);
            right.Dock = DockStyle.Fill;
            right.Margin = new Padding(4, 0, 0, 0);
            t.Controls.Add(left, 0, 0);
            t.Controls.Add(right, 1, 0);
            return t;
        }

        private static TableLayoutPanel MakeSwitchRow(string text, ToggleSwitch toggle)
        {
            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 2;
            t.RowCount = 1;
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            t.BackColor = UiTheme.PanelBg;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);

            Label label = new Label();
            label.Text = text;
            label.Dock = DockStyle.Fill;
            label.TextAlign = ContentAlignment.MiddleLeft;
            label.Font = UiTheme.FontUI(8.5F);
            label.ForeColor = UiTheme.TextSecondary;
            label.BackColor = Color.Transparent;
            label.Margin = new Padding(1, 0, 0, 0);
            t.Controls.Add(label, 0, 0);

            toggle.BackColor = UiTheme.PanelBg;
            toggle.Anchor = AnchorStyles.Right;
            toggle.Margin = new Padding(0);
            t.Controls.Add(toggle, 1, 0);
            return t;
        }

        private static Panel MakeDivider()
        {
            Panel p = new Panel();
            p.Dock = DockStyle.Fill;
            p.BackColor = UiTheme.PanelBg;
            p.Padding = new Padding(0, 9, 0, 9);
            p.Margin = new Padding(0);

            Panel line = new Panel();
            line.Dock = DockStyle.Bottom;
            line.Height = 1;
            line.BackColor = UiTheme.Border;
            line.Margin = new Padding(0);
            p.Controls.Add(line);
            return p;
        }

        private static ComboBox MakeCombo(int width, bool editable)
        {
            ComboBox c = new ComboBox();
            c.DropDownStyle = editable ? ComboBoxStyle.DropDown : ComboBoxStyle.DropDownList;
            c.FlatStyle = FlatStyle.Flat;
            c.Font = UiTheme.FontUI(9F);
            c.BackColor = UiTheme.Card;
            c.ForeColor = UiTheme.Text;
            c.IntegralHeight = false;
            c.Width = width;
            c.Margin = new Padding(0);
            return c;
        }

        private static ChipToggle MakeChip(string text, bool isChecked)
        {
            ChipToggle c = new ChipToggle();
            c.Text = text;
            c.Checked = isChecked;
            c.Margin = new Padding(0, 10, 6, 0);
            return c;
        }

        private static RoundButton MakeGhostButton(string text, int width)
        {
            RoundButton b = new RoundButton();
            b.Text = text;
            b.Size = new Size(width, 26);
            b.CornerRadius = 8;
            b.BackColor = UiTheme.Card;
            b.ForeColor = UiTheme.TextSecondary;
            b.BorderColor = UiTheme.Border;
            b.HoverColor = UiTheme.Blend(UiTheme.Card, Color.Black, 0.04);
            b.PressColor = UiTheme.Blend(UiTheme.Card, Color.Black, 0.08);
            b.Font = UiTheme.FontUI(8.5F);
            b.Margin = new Padding(0);
            return b;
        }

        private static RoundButton MakeWindowButton(string text)
        {
            RoundButton b = new RoundButton();
            b.Text = text;
            b.Size = new Size(30, 30);
            b.CornerRadius = 8;
            b.Font = UiTheme.FontUI(10F);
            b.BackColor = UiTheme.Card;
            b.ForeColor = UiTheme.TextSecondary;
            b.BorderColor = Color.Transparent;
            b.HoverColor = UiTheme.Blend(UiTheme.Card, Color.Black, 0.05);
            b.PressColor = UiTheme.Blend(UiTheme.Card, Color.Black, 0.1);
            b.Margin = new Padding(2, 0, 0, 0);
            return b;
        }

        private void SetConnPill(bool connected)
        {
            if (_connPill == null) return;

            if (connected)
            {
                _connPill.SetStyle("已连接",
                    UiTheme.SuccessSoft,
                    Color.FromArgb(191, 227, 191),
                    UiTheme.Success,
                    UiTheme.Success);
            }
            else
            {
                _connPill.SetStyle("未连接",
                    Color.FromArgb(245, 245, 247),
                    UiTheme.Border,
                    UiTheme.TextTertiary,
                    UiTheme.TextTertiary);
            }
        }

        private void ToggleMaximize()
        {
            _dragging = false;
            WindowState = WindowState == FormWindowState.Maximized
                ? FormWindowState.Normal
                : FormWindowState.Maximized;
            UpdateMaxButtonGlyph();
        }

        private void UpdateMaxButtonGlyph()
        {
            if (btnMax == null) return;
            btnMax.Text = WindowState == FormWindowState.Maximized ? "❐" : "□";
            btnMax.Invalidate();
        }

        private void AttachDrag(Control c)
        {
            c.MouseDown += TitleBar_MouseDown;
            c.MouseMove += TitleBar_MouseMove;
            c.MouseUp += TitleBar_MouseUp;
            c.MouseCaptureChanged += delegate
            {
                if (!c.Capture) _dragging = false;
            };
        }

        private void TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            if (WindowState == FormWindowState.Maximized) return;
            _dragging = true;
            _dragOffset = new Point(Cursor.Position.X - Left, Cursor.Position.Y - Top);
            Control c = sender as Control;
            if (c != null) c.Capture = true;
            Cursor = Cursors.SizeAll;
        }

        private void TitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_dragging) return;
            Location = new Point(Cursor.Position.X - _dragOffset.X, Cursor.Position.Y - _dragOffset.Y);
        }

        private void TitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
            Control c = sender as Control;
            if (c != null) c.Capture = false;
            Cursor = Cursors.Default;
        }

        private void UpdateEmptyState()
        {
            if (_lblRxEmpty != null)
                _lblRxEmpty.Visible = rtbRx.TextLength == 0;
        }

        private void PopulateCombos()
        {
            cboBaud.Items.AddRange(new object[] {
                "1200", "2400", "4800", "9600", "19200", "38400",
                "57600", "115200", "230400", "460800", "921600"
            });
            cboBaud.Text = "115200";

            cboDataBits.Items.AddRange(new object[] { "5", "6", "7", "8" });
            cboDataBits.SelectedItem = "8";

            cboStopBits.Items.AddRange(new object[] { "1", "1.5", "2" });
            cboStopBits.SelectedItem = "1";

            cboParity.Items.AddRange(new object[] { "无", "奇", "偶", "标记", "空格" });
            cboParity.SelectedItem = "无";

            cboFlow.Items.AddRange(new object[] { "无", "硬件 (RTS/CTS)", "软件 (XON/XOFF)", "硬件+软件" });
            cboFlow.SelectedItem = "无";

            cboEncoding.Items.AddRange(new object[] { "GBK", "UTF-8", "ASCII" });
            cboEncoding.SelectedItem = "GBK";

            cboLineEnd.Items.AddRange(new object[] { "CRLF", "CR", "LF" });
            cboLineEnd.SelectedItem = "CRLF";
        }

        private void RefreshPorts()
        {
            string current = cboPort.SelectedItem as string;

            string[] names = SerialPort.GetPortNames();
            Array.Sort(names, delegate(string a, string b)
            {
                int ia = int.MaxValue;
                int ib = int.MaxValue;
                if (a != null && a.Length > 3) int.TryParse(a.Substring(3), out ia);
                if (b != null && b.Length > 3) int.TryParse(b.Substring(3), out ib);
                if (ia == ib) return string.Compare(a, b, StringComparison.OrdinalIgnoreCase);
                return ia.CompareTo(ib);
            });

            cboPort.BeginUpdate();
            cboPort.Items.Clear();
            for (int i = 0; i < names.Length; i++) cboPort.Items.Add(names[i]);

            if (current != null && cboPort.Items.Contains(current))
                cboPort.SelectedItem = current;
            else if (cboPort.Items.Count > 0)
                cboPort.SelectedIndex = 0;
            cboPort.EndUpdate();
        }

        private void BindEvents()
        {
            btnOpen.Click += delegate { TogglePort(); };
            btnRefresh.Click += delegate { RefreshPorts(); UpdateStatus(); };
            btnW25.Click += delegate { OpenW25Qxx(); };
            btnClearRx.Click += delegate { ClearRx(); };
            btnSaveRx.Click += delegate { SaveRx(); };
            btnResetCount.Click += delegate { ResetCounters(); };
            btnSend.Click += delegate { SendCurrent(true); };
            btnClearTx.Click += delegate { rtbTx.Clear(); };
            btnSendFile.Click += delegate { SendFile(); };

            btnMin.Click += delegate { WindowState = FormWindowState.Minimized; };
            btnMax.Click += delegate { ToggleMaximize(); };
            btnClose.Click += delegate { Close(); };

            chkDtr.CheckedChanged += delegate
            {
                try { if (_port != null && _port.IsOpen) _port.DtrEnable = chkDtr.Checked; }
                catch { }
            };
            chkRts.CheckedChanged += delegate
            {
                try { if (_port != null && _port.IsOpen) _port.RtsEnable = chkRts.Checked; }
                catch { }
            };

            chkHexDisplay.CheckedChanged += delegate { RebuildDisplay(); };
            chkTimestamp.CheckedChanged += delegate { RebuildDisplay(); };
            chkWrap.CheckedChanged += delegate { rtbRx.WordWrap = chkWrap.Checked; };
            chkPause.CheckedChanged += delegate
            {
                if (!chkPause.Checked) RebuildDisplay();
            };

            cboEncoding.SelectedIndexChanged += delegate
            {
                string s = cboEncoding.SelectedItem as string;
                if (s == "UTF-8") _encoding = new UTF8Encoding(false);
                else if (s == "ASCII") _encoding = Encoding.ASCII;
                else _encoding = Encoding.GetEncoding(936);
                _decoder = _encoding.GetDecoder();
                RebuildDisplay();
            };

            chkNewLine.CheckedChanged += delegate { cboLineEnd.Enabled = chkNewLine.Checked; };
            chkRepeat.CheckedChanged += delegate
            {
                if (chkRepeat.Checked)
                {
                    _repeatTimer.Interval = (int)numInterval.Value;
                    _repeatTimer.Start();
                }
                else
                {
                    _repeatTimer.Stop();
                }
            };
            numInterval.ValueChanged += delegate
            {
                if (chkRepeat.Checked) _repeatTimer.Interval = (int)numInterval.Value;
            };

            rtbTx.KeyDown += RtbTx_KeyDown;
            FormClosing += MainForm_FormClosing;
        }

        private void RtbTx_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                e.Handled = true;
                SendCurrent(true);
            }
        }

        private void OpenW25Qxx()
        {
            string preferred = cboPort.SelectedItem as string;

            if (_port != null && _port.IsOpen)
            {
                DialogResult r = MessageBox.Show(this,
                    "W25Qxx 烧写需要独占串口，是否先关闭当前串口？",
                    "SCOM 串口调试助手",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r != DialogResult.Yes) return;

                ClosePort(true);
            }

            using (W25QxxForm f = new W25QxxForm(preferred))
            {
                f.ShowDialog(this);
            }

            RefreshPorts();
        }

        private void TogglePort()
        {
            if (_port != null && _port.IsOpen)
            {
                ClosePort(true);
                return;
            }

            string portName = cboPort.SelectedItem as string;
            if (string.IsNullOrEmpty(portName))
            {
                ShowError("未检测到可用串口，请检查设备连接后点击“刷新”。");
                return;
            }

            int baud;
            if (!int.TryParse(cboBaud.Text.Trim(), out baud) || baud <= 0)
            {
                ShowError("波特率无效，请输入大于 0 的整数。");
                return;
            }

            SerialPort sp = null;
            try
            {
                sp = new SerialPort(portName, baud, GetParity(), GetDataBits(), GetStopBits());
                sp.Handshake = GetHandshake();
                sp.ReadTimeout = 500;
                sp.WriteTimeout = 1000;
                try { sp.DtrEnable = chkDtr.Checked; }
                catch { }
                try { sp.RtsEnable = chkRts.Checked; }
                catch { }
                sp.DataReceived += Port_DataReceived;
                sp.Open();

                _port = sp;
                SetConfigEnabled(false);
                UpdateOpenButton();
                UpdateStatus();
            }
            catch (Exception ex)
            {
                if (sp != null)
                {
                    try
                    {
                        sp.DataReceived -= Port_DataReceived;
                        sp.Dispose();
                    }
                    catch { }
                }
                ShowError("打开串口失败：\r\n" + ex.Message);
            }
        }

        private void ClosePort(bool updateUi)
        {
            try
            {
                if (_port != null)
                {
                    _port.DataReceived -= Port_DataReceived;
                    if (_port.IsOpen) _port.Close();
                    _port.Dispose();
                }
            }
            catch { }
            finally
            {
                _port = null;
            }

            if (updateUi)
            {
                SetConfigEnabled(true);
                UpdateOpenButton();
                UpdateStatus();
            }
        }

        private void SetConfigEnabled(bool enabled)
        {
            cboPort.Enabled = enabled;
            cboBaud.Enabled = enabled;
            cboDataBits.Enabled = enabled;
            cboStopBits.Enabled = enabled;
            cboParity.Enabled = enabled;
            cboFlow.Enabled = enabled;
            btnRefresh.Enabled = enabled;
        }

        private void UpdateOpenButton()
        {
            bool open = _port != null && _port.IsOpen;
            btnOpen.Text = open ? "关闭串口" : "打开串口";

            if (open)
            {
                btnOpen.BackColor = UiTheme.Primary;
                btnOpen.ForeColor = Color.White;
                btnOpen.HoverColor = UiTheme.Accent;
                btnOpen.PressColor = UiTheme.Blend(UiTheme.Accent, Color.Black, 0.08);
            }
            else
            {
                btnOpen.BackColor = Color.FromArgb(239, 239, 242);
                btnOpen.ForeColor = UiTheme.Text;
                btnOpen.HoverColor = Color.FromArgb(231, 231, 235);
                btnOpen.PressColor = Color.FromArgb(222, 222, 227);
            }
        }

        private void UpdateStatus()
        {
            if (_port != null && _port.IsOpen)
            {
                lblStatus.Text = string.Format(
                    "已连接 · {0} · {1} {2}-{3}-{4}",
                    _port.PortName,
                    _port.BaudRate,
                    _port.DataBits,
                    ParityChar(_port.Parity),
                    StopChar(_port.StopBits));
                SetConnPill(true);
            }
            else
            {
                lblStatus.Text = "串口未打开 · 请选择端口";
                SetConnPill(false);
            }
        }

        private static string ParityChar(Parity p)
        {
            switch (p)
            {
                case Parity.Odd: return "O";
                case Parity.Even: return "E";
                case Parity.Mark: return "M";
                case Parity.Space: return "S";
                default: return "N";
            }
        }

        private static string StopChar(StopBits s)
        {
            switch (s)
            {
                case StopBits.OnePointFive: return "1.5";
                case StopBits.Two: return "2";
                default: return "1";
            }
        }

        private static string FlowText(Handshake h)
        {
            switch (h)
            {
                case Handshake.RequestToSend: return "RTS/CTS";
                case Handshake.XOnXOff: return "XON/XOFF";
                case Handshake.RequestToSendXOnXOff: return "RTS/CTS+XON/XOFF";
                default: return "无流控";
            }
        }

        private Parity GetParity()
        {
            string s = cboParity.SelectedItem as string;
            if (s == "奇") return Parity.Odd;
            if (s == "偶") return Parity.Even;
            if (s == "标记") return Parity.Mark;
            if (s == "空格") return Parity.Space;
            return Parity.None;
        }

        private int GetDataBits()
        {
            int v;
            if (int.TryParse(cboDataBits.SelectedItem as string, out v)) return v;
            return 8;
        }

        private StopBits GetStopBits()
        {
            string s = cboStopBits.SelectedItem as string;
            if (s == "1.5") return StopBits.OnePointFive;
            if (s == "2") return StopBits.Two;
            return StopBits.One;
        }

        private Handshake GetHandshake()
        {
            string s = cboFlow.SelectedItem as string;
            if (s == "硬件 (RTS/CTS)") return Handshake.RequestToSend;
            if (s == "软件 (XON/XOFF)") return Handshake.XOnXOff;
            if (s == "硬件+软件") return Handshake.RequestToSendXOnXOff;
            return Handshake.None;
        }

        private void Port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = sender as SerialPort;
            if (sp == null) return;

            try
            {
                int available = sp.BytesToRead;
                if (available <= 0) return;

                byte[] buffer = new byte[available];
                int read = sp.Read(buffer, 0, available);
                if (read <= 0) return;
                if (read < available) Array.Resize(ref buffer, read);

                Interlocked.Add(ref _rxTotal, read);

                lock (_rxLock)
                {
                    RxChunk chunk = new RxChunk();
                    chunk.Seq = ++_seq;
                    chunk.Time = DateTime.Now;
                    chunk.Data = buffer;
                    _rxHistory.Add(chunk);
                    _rxHistoryBytes += read;

                    while (_rxHistoryBytes > MaxHistoryBytes && _rxHistory.Count > 1)
                    {
                        _rxHistoryBytes -= _rxHistory[0].Data.Length;
                        _rxHistory.RemoveAt(0);
                    }
                }
            }
            catch { }
        }

        private void UiTimer_Tick(object sender, EventArgs e)
        {
            UpdateCounters();
            if (chkPause.Checked) return;

            List<RxChunk> chunks = null;
            bool rebuild = false;

            lock (_rxLock)
            {
                if (_rxHistory.Count > 0)
                {
                    long first = _rxHistory[0].Seq;
                    if (_lastRenderedSeq == 0 && first > 1) rebuild = true;
                    else if (_lastRenderedSeq != 0 && _lastRenderedSeq < first - 1) rebuild = true;

                    if (!rebuild)
                    {
                        chunks = new List<RxChunk>();
                        for (int i = 0; i < _rxHistory.Count; i++)
                        {
                            if (_rxHistory[i].Seq > _lastRenderedSeq) chunks.Add(_rxHistory[i]);
                        }
                    }
                }
            }

            if (rebuild)
            {
                RebuildDisplay();
                return;
            }
            if (chunks == null || chunks.Count == 0) return;

            AppendChunks(chunks);
        }

        private void AppendChunks(List<RxChunk> chunks)
        {
            rtbRx.SuspendLayout();
            for (int i = 0; i < chunks.Count; i++) AppendChunk(chunks[i]);
            _lastRenderedSeq = chunks[chunks.Count - 1].Seq;

            if (rtbRx.TextLength > MaxDisplayChars)
            {
                rtbRx.ResumeLayout();
                RebuildDisplay();
                return;
            }

            ScrollToEnd();
            rtbRx.ResumeLayout();
        }

        private void AppendChunk(RxChunk c)
        {
            if (chkTimestamp.Checked)
            {
                rtbRx.SelectionColor = Color.FromArgb(130, 140, 155);
                rtbRx.AppendText("[" + c.Time.ToString("HH:mm:ss.fff") + "] ");
                rtbRx.SelectionColor = Color.FromArgb(32, 32, 32);
            }

            if (chkHexDisplay.Checked)
            {
                rtbRx.AppendText(BytesToHex(c.Data));
                if (chkTimestamp.Checked) rtbRx.AppendText(Environment.NewLine);
            }
            else
            {
                char[] chars = new char[_encoding.GetMaxCharCount(c.Data.Length)];
                int count = _decoder.GetChars(c.Data, 0, c.Data.Length, chars, 0);
                rtbRx.AppendText(new string(chars, 0, count));
                if (chkTimestamp.Checked) rtbRx.AppendText(Environment.NewLine);
            }
        }

        private static string BytesToHex(byte[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 3);
            for (int i = 0; i < data.Length; i++)
            {
                sb.Append(data[i].ToString("X2"));
                sb.Append(' ');
            }
            return sb.ToString();
        }

        private void RebuildDisplay()
        {
            List<RxChunk> copy;
            lock (_rxLock) copy = new List<RxChunk>(_rxHistory);

            _decoder = _encoding.GetDecoder();
            rtbRx.SuspendLayout();
            rtbRx.Clear();
            for (int i = 0; i < copy.Count; i++) AppendChunk(copy[i]);
            if (copy.Count > 0) _lastRenderedSeq = copy[copy.Count - 1].Seq;
            ScrollToEnd();
            rtbRx.ResumeLayout();
        }

        private void ScrollToEnd()
        {
            if (!chkAutoScroll.Checked) return;
            rtbRx.SelectionStart = rtbRx.TextLength;
            rtbRx.SelectionLength = 0;
            rtbRx.ScrollToCaret();
        }

        private void ClearRx()
        {
            lock (_rxLock)
            {
                _rxHistory.Clear();
                _rxHistoryBytes = 0;
                _lastRenderedSeq = _seq;
            }
            _decoder = _encoding.GetDecoder();
            rtbRx.Clear();
        }

        private void ResetCounters()
        {
            Interlocked.Exchange(ref _rxTotal, 0);
            Interlocked.Exchange(ref _txTotal, 0);
            UpdateCounters();
        }

        private void UpdateCounters()
        {
            lblRx.Text = string.Format("RX {0:N0} B", Interlocked.Read(ref _rxTotal));
            lblTx.Text = string.Format("TX {0:N0} B", Interlocked.Read(ref _txTotal));
        }

        private void SaveRx()
        {
            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Title = "保存接收数据";
                dlg.Filter = "文本文件 (*.txt)|*.txt|所有文件 (*.*)|*.*";
                dlg.FileName = "scom_rx_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";

                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllText(dlg.FileName, rtbRx.Text, new UTF8Encoding(true));
                    }
                    catch (Exception ex)
                    {
                        ShowError("保存失败：\r\n" + ex.Message);
                    }
                }
            }
        }

        private void RepeatTimer_Tick(object sender, EventArgs e)
        {
            if (_port == null || !_port.IsOpen) return;
            SendCurrent(false);
        }

        private void SendCurrent(bool showError)
        {
            if (_port == null || !_port.IsOpen)
            {
                if (showError) ShowError("串口未打开，请先打开串口。");
                return;
            }

            byte[] data;
            string error;
            if (!TryBuildPayload(out data, out error))
            {
                if (showError) ShowError(error);
                else
                {
                    chkRepeat.Checked = false;
                    lblStatus.Text = "定时发送已停止：" + error;
                }
                return;
            }

            if (data.Length == 0) return;

            try
            {
                _port.Write(data, 0, data.Length);
                Interlocked.Add(ref _txTotal, data.Length);
                UpdateCounters();
            }
            catch (Exception ex)
            {
                if (showError)
                {
                    ShowError("发送失败：\r\n" + ex.Message);
                }
                else
                {
                    chkRepeat.Checked = false;
                    lblStatus.Text = "发送失败：" + ex.Message;
                }
            }
        }

        private void SendFile()
        {
            if (_port == null || !_port.IsOpen)
            {
                ShowError("串口未打开，请先打开串口。");
                return;
            }

            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "发送文件";
                dlg.Filter = "所有文件 (*.*)|*.*";

                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    byte[] data = File.ReadAllBytes(dlg.FileName);
                    if (data.Length == 0) return;

                    _port.Write(data, 0, data.Length);
                    Interlocked.Add(ref _txTotal, data.Length);
                    UpdateCounters();
                }
                catch (Exception ex)
                {
                    ShowError("发送文件失败：\r\n" + ex.Message);
                }
            }
        }

        private bool TryBuildPayload(out byte[] data, out string error)
        {
            data = null;
            error = null;

            string text = rtbTx.Text;

            if (chkHexSend.Checked)
            {
                return TryParseHex(text, out data, out error);
            }

            if (chkNewLine.Checked) text += LineEnding();
            data = _encoding.GetBytes(text);
            return true;
        }

        private string LineEnding()
        {
            string s = cboLineEnd.SelectedItem as string;
            if (s == "CR") return "\r";
            if (s == "LF") return "\n";
            return "\r\n";
        }

        private static bool TryParseHex(string text, out byte[] result, out string error)
        {
            result = null;
            error = null;

            List<byte> bytes = new List<byte>();
            string cleaned = Regex.Replace(text, "0[xX]", " ");
            int high = -1;

            for (int i = 0; i < cleaned.Length; i++)
            {
                char c = cleaned[i];
                int v = HexValue(c);

                if (v >= 0)
                {
                    if (high < 0)
                    {
                        high = v;
                    }
                    else
                    {
                        bytes.Add((byte)((high << 4) | v));
                        high = -1;
                    }
                }
                else if (char.IsWhiteSpace(c) || c == ',' || c == ';' || c == ':' || c == '-' || c == '_')
                {
                    continue;
                }
                else
                {
                    error = "HEX 数据包含无效字符：'" + c + "'";
                    return false;
                }
            }

            if (high >= 0)
            {
                error = "HEX 数据位数为奇数，请检查输入。";
                return false;
            }

            result = bytes.ToArray();
            return true;
        }

        private static int HexValue(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return -1;
        }

        private void ShowError(string message)
        {
            MessageBox.Show(this, message, "SCOM 串口调试助手",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private static string SettingsPath
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "Scom", "settings.ini");
            }
        }

        private void LoadSettings()
        {
            try
            {
                string path = SettingsPath;
                if (!File.Exists(path)) return;

                Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string raw in File.ReadAllLines(path))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#") || line.StartsWith(";")) continue;
                    int idx = line.IndexOf('=');
                    if (idx <= 0) continue;
                    d[line.Substring(0, idx).Trim()] = line.Substring(idx + 1).Trim();
                }

                string v;
                if (d.TryGetValue("port", out v)) SelectCombo(cboPort, v);
                if (d.TryGetValue("baud", out v)) cboBaud.Text = v;
                if (d.TryGetValue("databits", out v)) SelectCombo(cboDataBits, v);
                if (d.TryGetValue("stopbits", out v)) SelectCombo(cboStopBits, v);
                if (d.TryGetValue("parity", out v)) SelectCombo(cboParity, v);
                if (d.TryGetValue("flow", out v)) SelectCombo(cboFlow, v);
                if (d.TryGetValue("encoding", out v)) SelectCombo(cboEncoding, v);

                if (d.TryGetValue("dtr", out v)) chkDtr.Checked = v == "1";
                if (d.TryGetValue("rts", out v)) chkRts.Checked = v == "1";
                if (d.TryGetValue("hexdisplay", out v)) chkHexDisplay.Checked = v == "1";
                if (d.TryGetValue("timestamp", out v)) chkTimestamp.Checked = v == "1";
                if (d.TryGetValue("wrap", out v)) chkWrap.Checked = v == "1";
                if (d.TryGetValue("autoscroll", out v)) chkAutoScroll.Checked = v == "1";
                if (d.TryGetValue("hexsend", out v)) chkHexSend.Checked = v == "1";
                if (d.TryGetValue("newline", out v)) chkNewLine.Checked = v == "1";
                if (d.TryGetValue("lineend", out v)) SelectCombo(cboLineEnd, v);

                if (d.TryGetValue("interval", out v))
                {
                    decimal n;
                    if (decimal.TryParse(v, out n))
                    {
                        if (n < numInterval.Minimum) n = numInterval.Minimum;
                        if (n > numInterval.Maximum) n = numInterval.Maximum;
                        numInterval.Value = n;
                    }
                }

                int w;
                int h;
                if (d.TryGetValue("width", out v) && int.TryParse(v, out w) && w >= MinimumSize.Width) _restoreWidth = w;
                if (d.TryGetValue("height", out v) && int.TryParse(v, out h) && h >= MinimumSize.Height) _restoreHeight = h;

                if (d.TryGetValue("maximized", out v) && v == "1")
                    WindowState = FormWindowState.Maximized;

                cboLineEnd.Enabled = chkNewLine.Checked;
            }
            catch { }
        }

        private static void SelectCombo(ComboBox cbo, string value)
        {
            if (string.IsNullOrEmpty(value)) return;

            int idx = cbo.Items.IndexOf(value);
            if (idx >= 0)
            {
                cbo.SelectedIndex = idx;
            }
            else if (cbo.DropDownStyle == ComboBoxStyle.DropDown)
            {
                cbo.Text = value;
            }
            else
            {
                cbo.Items.Add(value);
                cbo.SelectedItem = value;
            }
        }

        private static string B(bool value)
        {
            return value ? "1" : "0";
        }

        private void SaveSettings()
        {
            try
            {
                string path = SettingsPath;
                Directory.CreateDirectory(Path.GetDirectoryName(path));

                List<string> lines = new List<string>();
                lines.Add("# SCOM serial assistant settings");
                lines.Add("port=" + (cboPort.SelectedItem as string ?? ""));
                lines.Add("baud=" + cboBaud.Text.Trim());
                lines.Add("databits=" + (cboDataBits.SelectedItem as string ?? ""));
                lines.Add("stopbits=" + (cboStopBits.SelectedItem as string ?? ""));
                lines.Add("parity=" + (cboParity.SelectedItem as string ?? ""));
                lines.Add("flow=" + (cboFlow.SelectedItem as string ?? ""));
                lines.Add("encoding=" + (cboEncoding.SelectedItem as string ?? ""));
                lines.Add("dtr=" + B(chkDtr.Checked));
                lines.Add("rts=" + B(chkRts.Checked));
                lines.Add("hexdisplay=" + B(chkHexDisplay.Checked));
                lines.Add("timestamp=" + B(chkTimestamp.Checked));
                lines.Add("wrap=" + B(chkWrap.Checked));
                lines.Add("autoscroll=" + B(chkAutoScroll.Checked));
                lines.Add("hexsend=" + B(chkHexSend.Checked));
                lines.Add("newline=" + B(chkNewLine.Checked));
                lines.Add("lineend=" + (cboLineEnd.SelectedItem as string ?? ""));
                lines.Add("interval=" + ((int)numInterval.Value).ToString());
                lines.Add("width=" + Width.ToString());
                lines.Add("height=" + Height.ToString());
                lines.Add("maximized=" + B(WindowState == FormWindowState.Maximized));

                File.WriteAllLines(path, lines.ToArray(), new UTF8Encoding(true));
            }
            catch { }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            _uiTimer.Stop();
            _repeatTimer.Stop();
            ClosePort(false);
            SaveSettings();
        }
    }
}
