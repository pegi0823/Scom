using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;

namespace Scom
{
    public class W25QxxForm : Form
    {
        private static readonly Color Accent = UiTheme.Accent;
        private static readonly Color OpenGreen = UiTheme.Success;
        private static readonly Color TextDark = UiTheme.Text;
        private static readonly Color TextMuted = UiTheme.TextSecondary;
        private static readonly Color LogBg = UiTheme.LogBg;

        private readonly string _preferredPort;
        private readonly W25QxxProgrammer _prog = new W25QxxProgrammer();

        private byte[] _fileData;
        private volatile bool _busy;

        private string _lastProgressStage;
        private int _lastProgressPercent = -1;
        private int _lastProgressTick;

        private ComboBox cboPort;
        private RoundButton btnRefresh;
        private RoundButton btnConnect;
        private RoundButton btnDisconnect;
        private RoundButton btnReadId;
        private RoundButton btnEraseChip;
        private RoundButton btnBrowse;
        private RoundButton btnProgram;
        private RoundButton btnAutoProgram;
        private RoundButton btnStop;
        private RoundButton btnClose;
        private RoundButton btnClearLog;

        private PillLabel _connPill;
        private PillLabel _statePill;
        private PillLabel _idPill;

        private Label _lblFileName;
        private Label _lblFileMeta;
        private Label _lblProgLabel;
        private Label _lblProgPct;

        private InfoRow _rowModel;
        private InfoRow _rowManu;
        private InfoRow _rowDev;
        private InfoRow _rowSize;
        private InfoRow _rowPage;

        private Label _statOk;
        private Label _statNg;
        private Label _statTime;

        private TextBox txtStartAddr;
        private RoundCheckBox chkVerify;
        private RoundCheckBox chkContinuous;
        private StepChips _steps;
        private SlimProgress _progress;
        private RichTextBox txtLog;
        private ToolTip _tip;

        private int _okCount;
        private int _ngCount;
        private string _lastDurationText = "—";

        private bool _dragging;
        private Point _dragOffset;

        public W25QxxForm(string preferredPort)
        {
            _preferredPort = preferredPort;

            BuildUi();
            BindEvents();
            RefreshPorts();
            UpdateUiState();
            AppendLog("W25Qxx Flash 烧录工具已就绪，请选择串口并连接设备。", TextDark);
            AppendLog("全自动烧录会自动连接并完成读ID、擦除、写入、校验；勾选“连续烧录”可循环生产。", TextMuted);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            UpdateWindowRegion();
        }

        private void UpdateWindowRegion()
        {
            if (Width <= 0 || Height <= 0) return;

            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0, 0, Width, Height), 16F))
            {
                Region old = Region;
                Region = new Region(path);
                if (old != null) old.Dispose();
            }
        }

        private void BuildUi()
        {
            SuspendLayout();

            Text = "W25Qxx Flash 烧录工具";
            Font = UiTheme.FontUI(9F);
            BackColor = UiTheme.Background;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(920, 820);
            MinimumSize = new Size(920, 820);
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            KeyPreview = true;

            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.Padding = new Padding(16, 14, 16, 14);
            root.ColumnCount = 1;
            root.RowCount = 4;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58F));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 184F));
            root.BackColor = UiTheme.Background;
            root.Margin = new Padding(0);

            root.Controls.Add(BuildTitleBar(), 0, 0);
            root.Controls.Add(BuildToolbar(), 0, 1);
            root.Controls.Add(BuildMainGrid(), 0, 2);
            root.Controls.Add(BuildLogCard(), 0, 3);

            Controls.Add(root);

            ResumeLayout(false);
            PerformLayout();
            UpdateWindowRegion();
        }

        private Panel BuildTitleBar()
        {
            Panel bar = new Panel();
            bar.Dock = DockStyle.Fill;
            bar.BackColor = UiTheme.Background;
            bar.Margin = new Padding(0, 0, 0, 6);

            Panel line = new Panel();
            line.Dock = DockStyle.Bottom;
            line.Height = 1;
            line.BackColor = UiTheme.Border;
            bar.Controls.Add(line);

            TableLayoutPanel grid = new TableLayoutPanel();
            grid.Dock = DockStyle.Fill;
            grid.ColumnCount = 4;
            grid.RowCount = 1;
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 38F));
            grid.Padding = new Padding(2, 0, 2, 9);
            grid.BackColor = UiTheme.Background;
            grid.Margin = new Padding(0);
            bar.Controls.Add(grid);

            RoundPanel logo = new RoundPanel();
            logo.CornerRadius = 9;
            logo.BorderColor = Color.Transparent;
            logo.BackColor = UiTheme.PrimarySoft;
            logo.Size = new Size(30, 30);
            logo.Margin = new Padding(0);
            logo.Anchor = AnchorStyles.Left;

            Label logoText = new Label();
            logoText.Text = "W25Q";
            logoText.Dock = DockStyle.Fill;
            logoText.TextAlign = ContentAlignment.MiddleCenter;
            logoText.Font = new Font("Segoe UI", 6F, FontStyle.Bold, GraphicsUnit.Point);
            logoText.ForeColor = UiTheme.Accent;
            logoText.BackColor = Color.Transparent;
            logo.Controls.Add(logoText);
            grid.Controls.Add(logo, 0, 0);

            TableLayoutPanel stack = new TableLayoutPanel();
            stack.Dock = DockStyle.Fill;
            stack.ColumnCount = 1;
            stack.RowCount = 3;
            stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 21F));
            stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 16F));
            stack.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            stack.BackColor = UiTheme.Background;
            stack.Margin = new Padding(8, 0, 8, 0);
            stack.Padding = new Padding(0);

            Label title = new Label();
            title.Text = "W25Qxx Flash 烧录工具";
            title.Dock = DockStyle.Fill;
            title.TextAlign = ContentAlignment.BottomLeft;
            title.Font = UiTheme.FontUI(10F);
            title.ForeColor = UiTheme.Text;
            title.BackColor = Color.Transparent;
            title.AutoSize = false;
            title.Margin = new Padding(0);

            Label sub = new Label();
            sub.Text = "v1.2.0 · CH340 · 115200 8N1";
            sub.Dock = DockStyle.Fill;
            sub.TextAlign = ContentAlignment.TopLeft;
            sub.Font = UiTheme.FontUI(8F);
            sub.ForeColor = UiTheme.TextTertiary;
            sub.BackColor = Color.Transparent;
            sub.AutoSize = false;
            sub.Margin = new Padding(0);

            stack.Controls.Add(title, 0, 0);
            stack.Controls.Add(sub, 0, 1);
            grid.Controls.Add(stack, 1, 0);

            _connPill = new PillLabel();
            _connPill.Anchor = AnchorStyles.Right;
            _connPill.Margin = new Padding(0, 0, 10, 0);
            SetConnPill(false, null);
            grid.Controls.Add(_connPill, 2, 0);

            btnClose = new RoundButton();
            btnClose.Text = "×";
            btnClose.Font = UiTheme.FontUI(13F);
            btnClose.Size = new Size(30, 30);
            btnClose.CornerRadius = 8;
            btnClose.BackColor = UiTheme.Background;
            btnClose.ForeColor = UiTheme.TextSecondary;
            btnClose.HoverColor = UiTheme.Blend(UiTheme.Background, Color.Black, 0.06);
            btnClose.PressColor = UiTheme.Blend(UiTheme.Background, Color.Black, 0.12);
            btnClose.BorderColor = Color.Transparent;
            btnClose.Anchor = AnchorStyles.Right;
            btnClose.Margin = new Padding(0);
            grid.Controls.Add(btnClose, 3, 0);

            AttachDrag(bar);
            AttachDrag(grid);
            AttachDrag(logo);
            AttachDrag(logoText);
            AttachDrag(stack);
            AttachDrag(title);
            AttachDrag(sub);

            return bar;
        }

        private RoundPanel BuildToolbar()
        {
            RoundPanel bar = new RoundPanel();
            bar.Dock = DockStyle.Fill;
            bar.CornerRadius = 14;
            bar.BorderColor = UiTheme.Border;
            bar.BackColor = UiTheme.Card;
            bar.Padding = new Padding(14, 6, 14, 6);
            bar.Margin = new Padding(0, 0, 0, 12);

            TableLayoutPanel grid = new TableLayoutPanel();
            grid.Dock = DockStyle.Fill;
            grid.ColumnCount = 8;
            grid.RowCount = 1;
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 104F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 116F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            grid.BackColor = UiTheme.Card;
            grid.Margin = new Padding(0);
            grid.Padding = new Padding(0);
            bar.Controls.Add(grid);

            Label portLabel = MakeFieldLabel("串口");
            portLabel.Margin = new Padding(0, 0, 8, 0);
            grid.Controls.Add(portLabel, 0, 0);

            cboPort = new ComboBox();
            cboPort.DropDownStyle = ComboBoxStyle.DropDownList;
            cboPort.FlatStyle = FlatStyle.Flat;
            cboPort.Font = UiTheme.FontUI(9F);
            cboPort.Width = 96;
            cboPort.Anchor = AnchorStyles.Left;
            cboPort.Margin = new Padding(0, 0, 16, 0);
            grid.Controls.Add(cboPort, 1, 0);

            Label baudLabel = MakeFieldLabel("波特率");
            baudLabel.Margin = new Padding(0, 0, 8, 0);
            grid.Controls.Add(baudLabel, 2, 0);

            PillLabel baudPill = new PillLabel();
            baudPill.Font = UiTheme.FontUI(8.5F);
            baudPill.SetStyle("115200 8N1",
                Color.FromArgb(247, 247, 249), UiTheme.Border, UiTheme.TextSecondary, Color.Empty);
            baudPill.Anchor = AnchorStyles.Left;
            baudPill.Margin = new Padding(0, 0, 16, 0);
            grid.Controls.Add(baudPill, 3, 0);

            btnRefresh = MakeToolButton("刷新", 56);
            btnRefresh.Margin = new Padding(0);
            grid.Controls.Add(btnRefresh, 4, 0);

            Panel spacer = new Panel();
            spacer.Dock = DockStyle.Fill;
            spacer.BackColor = UiTheme.Card;
            spacer.Margin = new Padding(0);
            grid.Controls.Add(spacer, 5, 0);

            btnConnect = MakeToolButton("连接设备", 96);
            btnConnect.BackColor = UiTheme.Primary;
            btnConnect.ForeColor = Color.White;
            btnConnect.Font = UiTheme.FontUI(9F, FontStyle.Bold);
            btnConnect.BorderColor = Color.Transparent;
            btnConnect.HoverColor = UiTheme.Accent;
            btnConnect.PressColor = UiTheme.Blend(UiTheme.Accent, Color.Black, 0.08);
            btnConnect.Margin = new Padding(0, 0, 8, 0);
            grid.Controls.Add(btnConnect, 6, 0);

            btnDisconnect = MakeToolButton("断开", 64);
            btnDisconnect.Margin = new Padding(0);
            grid.Controls.Add(btnDisconnect, 7, 0);

            return bar;
        }

        private TableLayoutPanel BuildMainGrid()
        {
            TableLayoutPanel grid = new TableLayoutPanel();
            grid.Dock = DockStyle.Fill;
            grid.ColumnCount = 2;
            grid.RowCount = 1;
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43F));
            grid.BackColor = UiTheme.Background;
            grid.Margin = new Padding(0);
            grid.Padding = new Padding(0);

            RoundPanel programCard = BuildProgramCard();
            programCard.Margin = new Padding(0, 0, 6, 0);
            grid.Controls.Add(programCard, 0, 0);

            TableLayoutPanel right = new TableLayoutPanel();
            right.Dock = DockStyle.Fill;
            right.ColumnCount = 1;
            right.RowCount = 4;
            right.RowStyles.Add(new RowStyle(SizeType.Absolute, 304F));
            right.RowStyles.Add(new RowStyle(SizeType.Absolute, 12F));
            right.RowStyles.Add(new RowStyle(SizeType.Absolute, 156F));
            right.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            right.BackColor = UiTheme.Background;
            right.Margin = new Padding(6, 0, 0, 0);
            right.Padding = new Padding(0);

            RoundPanel infoCard = BuildInfoCard();
            infoCard.Margin = new Padding(0);
            right.Controls.Add(infoCard, 0, 0);

            Panel gap = new Panel();
            gap.Dock = DockStyle.Fill;
            gap.BackColor = UiTheme.Background;
            gap.Margin = new Padding(0);
            right.Controls.Add(gap, 0, 1);

            RoundPanel statsCard = BuildStatsCard();
            statsCard.Margin = new Padding(0);
            right.Controls.Add(statsCard, 0, 2);

            grid.Controls.Add(right, 1, 0);
            return grid;
        }

        private RoundPanel BuildProgramCard()
        {
            RoundPanel card = MakeCard();

            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 1;
            t.RowCount = 9;
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 26F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 60F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 42F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 16F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            t.BackColor = UiTheme.Card;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);
            card.Controls.Add(t);

            _statePill = new PillLabel();
            SetStatePill("就绪", 0);
            t.Controls.Add(MakeCardHeader("固件烧写", _statePill), 0, 0);

            RoundPanel fileRow = new RoundPanel();
            fileRow.Dock = DockStyle.Fill;
            fileRow.CornerRadius = 10;
            fileRow.BorderColor = UiTheme.Border;
            fileRow.BackColor = UiTheme.InputBg;
            fileRow.Padding = new Padding(10, 6, 10, 6);
            fileRow.Margin = new Padding(0, 8, 0, 0);

            TableLayoutPanel fileGrid = new TableLayoutPanel();
            fileGrid.Dock = DockStyle.Fill;
            fileGrid.ColumnCount = 3;
            fileGrid.RowCount = 1;
            fileGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            fileGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 42F));
            fileGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            fileGrid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            fileGrid.BackColor = UiTheme.InputBg;
            fileGrid.Margin = new Padding(0);
            fileRow.Controls.Add(fileGrid);

            RoundPanel fileIcon = new RoundPanel();
            fileIcon.CornerRadius = 8;
            fileIcon.BorderColor = Color.Transparent;
            fileIcon.BackColor = UiTheme.BlueSoft;
            fileIcon.Size = new Size(32, 32);
            fileIcon.Anchor = AnchorStyles.Left;
            fileIcon.Margin = new Padding(0, 0, 10, 0);
            Label iconText = new Label();
            iconText.Text = "BIN";
            iconText.Dock = DockStyle.Fill;
            iconText.TextAlign = ContentAlignment.MiddleCenter;
            iconText.Font = UiTheme.FontUI(7F, FontStyle.Bold);
            iconText.ForeColor = UiTheme.Blue;
            iconText.BackColor = Color.Transparent;
            fileIcon.Controls.Add(iconText);
            fileGrid.Controls.Add(fileIcon, 0, 0);

            TableLayoutPanel fileStack = new TableLayoutPanel();
            fileStack.Dock = DockStyle.Fill;
            fileStack.ColumnCount = 1;
            fileStack.RowCount = 3;
            fileStack.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            fileStack.RowStyles.Add(new RowStyle(SizeType.Absolute, 18F));
            fileStack.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            fileStack.BackColor = UiTheme.InputBg;
            fileStack.Margin = new Padding(0);
            fileStack.Padding = new Padding(0);

            _lblFileName = new Label();
            _lblFileName.Text = "未选择固件文件";
            _lblFileName.Dock = DockStyle.Fill;
            _lblFileName.TextAlign = ContentAlignment.BottomLeft;
            _lblFileName.Font = UiTheme.FontUI(9.5F, FontStyle.Bold);
            _lblFileName.ForeColor = UiTheme.Text;
            _lblFileName.AutoEllipsis = true;
            _lblFileName.AutoSize = false;
            _lblFileName.BackColor = Color.Transparent;
            _lblFileName.Margin = new Padding(0);

            _lblFileMeta = new Label();
            _lblFileMeta.Text = "请选择 .bin 固件文件";
            _lblFileMeta.Dock = DockStyle.Fill;
            _lblFileMeta.TextAlign = ContentAlignment.TopLeft;
            _lblFileMeta.Font = UiTheme.FontUI(8F);
            _lblFileMeta.ForeColor = UiTheme.TextTertiary;
            _lblFileMeta.AutoEllipsis = true;
            _lblFileMeta.AutoSize = false;
            _lblFileMeta.BackColor = Color.Transparent;
            _lblFileMeta.Margin = new Padding(0);

            fileStack.Controls.Add(_lblFileName, 0, 0);
            fileStack.Controls.Add(_lblFileMeta, 0, 1);
            fileGrid.Controls.Add(fileStack, 1, 0);

            btnBrowse = MakeToolButton("浏览", 64);
            btnBrowse.Height = 30;
            btnBrowse.Font = UiTheme.FontUI(8.5F);
            btnBrowse.Anchor = AnchorStyles.Right;
            btnBrowse.Margin = new Padding(8, 0, 0, 0);
            fileGrid.Controls.Add(btnBrowse, 2, 0);

            t.Controls.Add(fileRow, 0, 1);

            TableLayoutPanel options = new TableLayoutPanel();
            options.Dock = DockStyle.Fill;
            options.ColumnCount = 5;
            options.RowCount = 1;
            options.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            options.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            options.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112F));
            options.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            options.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            options.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            options.BackColor = UiTheme.Card;
            options.Margin = new Padding(0, 8, 0, 0);
            options.Padding = new Padding(0);

            Label addrLabel = MakeFieldLabel("起始地址");
            addrLabel.Margin = new Padding(0, 0, 8, 0);
            options.Controls.Add(addrLabel, 0, 0);

            txtStartAddr = new TextBox();
            txtStartAddr.Text = "0x000000";
            txtStartAddr.Font = UiTheme.FontMono(9.5F);
            txtStartAddr.BorderStyle = BorderStyle.FixedSingle;
            txtStartAddr.Width = 104;
            txtStartAddr.Anchor = AnchorStyles.Left;
            txtStartAddr.Margin = new Padding(0, 0, 18, 0);
            options.Controls.Add(txtStartAddr, 1, 0);

            chkVerify = new RoundCheckBox();
            chkVerify.Text = "烧写后校验";
            chkVerify.Checked = true;
            chkVerify.Anchor = AnchorStyles.Left;
            chkVerify.Margin = new Padding(0, 0, 18, 0);
            options.Controls.Add(chkVerify, 2, 0);

            chkContinuous = new RoundCheckBox();
            chkContinuous.Text = "连续烧录";
            chkContinuous.Anchor = AnchorStyles.Left;
            chkContinuous.Margin = new Padding(0, 0, 0, 0);
            options.Controls.Add(chkContinuous, 3, 0);

            t.Controls.Add(options, 0, 2);

            _steps = new StepChips();
            _steps.Dock = DockStyle.Fill;
            _steps.Margin = new Padding(0, 8, 0, 0);
            t.Controls.Add(_steps, 0, 3);

            _progress = new SlimProgress();
            _progress.Dock = DockStyle.Fill;
            _progress.Margin = new Padding(0, 6, 0, 0);
            t.Controls.Add(_progress, 0, 4);

            TableLayoutPanel meta = new TableLayoutPanel();
            meta.Dock = DockStyle.Fill;
            meta.ColumnCount = 2;
            meta.RowCount = 1;
            meta.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            meta.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            meta.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            meta.BackColor = UiTheme.Card;
            meta.Margin = new Padding(0, 4, 0, 0);

            _lblProgLabel = new Label();
            _lblProgLabel.Text = "等待开始";
            _lblProgLabel.Dock = DockStyle.Fill;
            _lblProgLabel.TextAlign = ContentAlignment.MiddleLeft;
            _lblProgLabel.Font = UiTheme.FontUI(8.5F);
            _lblProgLabel.ForeColor = UiTheme.TextTertiary;
            _lblProgLabel.AutoSize = false;
            _lblProgLabel.Margin = new Padding(0);

            _lblProgPct = new Label();
            _lblProgPct.Text = "0%";
            _lblProgPct.Dock = DockStyle.Fill;
            _lblProgPct.TextAlign = ContentAlignment.MiddleRight;
            _lblProgPct.Font = UiTheme.FontUI(8.5F);
            _lblProgPct.ForeColor = UiTheme.TextTertiary;
            _lblProgPct.AutoSize = false;
            _lblProgPct.Margin = new Padding(0);

            meta.Controls.Add(_lblProgLabel, 0, 0);
            meta.Controls.Add(_lblProgPct, 1, 0);
            t.Controls.Add(meta, 0, 5);

            RoundPanel tip = new RoundPanel();
            tip.Dock = DockStyle.Fill;
            tip.CornerRadius = 10;
            tip.BorderColor = Color.Transparent;
            tip.BackColor = UiTheme.PrimarySoft;
            tip.Padding = new Padding(10, 6, 10, 6);
            tip.Margin = new Padding(0, 0, 0, 10);

            Label tipText = new Label();
            tipText.Text = "连续烧录：烧录成功后取走芯片，检测到新芯片会自动开始下一片。需下载器支持热插拔检测。";
            tipText.Dock = DockStyle.Fill;
            tipText.TextAlign = ContentAlignment.MiddleLeft;
            tipText.Font = UiTheme.FontUI(8F);
            tipText.ForeColor = UiTheme.Accent;
            tipText.AutoSize = false;
            tipText.BackColor = Color.Transparent;
            tipText.Margin = new Padding(0);
            tip.Controls.Add(tipText);
            t.Controls.Add(tip, 0, 7);

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.Dock = DockStyle.Fill;
            buttons.FlowDirection = FlowDirection.LeftToRight;
            buttons.WrapContents = false;
            buttons.BackColor = UiTheme.Card;
            buttons.Margin = new Padding(0);
            buttons.Padding = new Padding(0);

            btnProgram = MakePrimaryButton("开始烧写", 104);
            btnProgram.Margin = new Padding(0, 0, 8, 0);
            buttons.Controls.Add(btnProgram);

            btnAutoProgram = new RoundButton();
            btnAutoProgram.Text = "全自动烧录";
            btnAutoProgram.Width = 116;
            btnAutoProgram.Height = 36;
            btnAutoProgram.CornerRadius = 10;
            btnAutoProgram.BackColor = UiTheme.PrimarySoft;
            btnAutoProgram.ForeColor = UiTheme.Accent;
            btnAutoProgram.BorderColor = Color.FromArgb(243, 199, 154);
            btnAutoProgram.HoverColor = Color.FromArgb(250, 226, 204);
            btnAutoProgram.PressColor = Color.FromArgb(247, 214, 183);
            btnAutoProgram.Font = UiTheme.FontUI(9F, FontStyle.Bold);
            btnAutoProgram.Margin = new Padding(0, 0, 8, 0);
            buttons.Controls.Add(btnAutoProgram);

            btnStop = MakeDangerButton("停止", 68);
            btnStop.Margin = new Padding(0);
            buttons.Controls.Add(btnStop);

            t.Controls.Add(buttons, 0, 8);

            _tip = new ToolTip();
            _tip.SetToolTip(btnClose, "关闭");
            _tip.SetToolTip(btnAutoProgram, "自动连接串口，并完成读取 Flash ID、擦除、写入和校验。");
            _tip.SetToolTip(chkContinuous, "勾选后，每片烧录成功会等待取走芯片；检测到新芯片后自动开始下一片。需下载器支持热插拔检测。");
            _tip.SetToolTip(btnStop, "停止当前烧录或连续生产。");

            return card;
        }

        private RoundPanel BuildInfoCard()
        {
            RoundPanel card = MakeCard();

            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 1;
            t.RowCount = 6;
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 10F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 160F));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 38F));
            t.BackColor = UiTheme.Card;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);
            card.Controls.Add(t);

            _idPill = new PillLabel();
            SetIdPill("未读取", 0);
            t.Controls.Add(MakeCardHeader("Flash 信息", _idPill), 0, 0);

            TableLayoutPanel rows = new TableLayoutPanel();
            rows.Dock = DockStyle.Fill;
            rows.ColumnCount = 1;
            rows.RowCount = 6;
            for (int i = 0; i < 5; i++)
                rows.RowStyles.Add(new RowStyle(SizeType.Absolute, 32F));
            rows.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            rows.BackColor = UiTheme.Card;
            rows.Margin = new Padding(0);
            rows.Padding = new Padding(0);

            _rowModel = MakeInfoRow("芯片型号");
            _rowManu = MakeInfoRow("厂商 ID");
            _rowDev = MakeInfoRow("器件 ID");
            _rowSize = MakeInfoRow("容量");
            _rowPage = MakeInfoRow("页 / 扇区");
            _rowPage.ShowSeparator = false;

            rows.Controls.Add(_rowModel, 0, 0);
            rows.Controls.Add(_rowManu, 0, 1);
            rows.Controls.Add(_rowDev, 0, 2);
            rows.Controls.Add(_rowSize, 0, 3);
            rows.Controls.Add(_rowPage, 0, 4);
            t.Controls.Add(rows, 0, 2);

            Label note = new Label();
            note.Text = "提示：读取 ID 可自动识别型号与容量。";
            note.Dock = DockStyle.Fill;
            note.TextAlign = ContentAlignment.BottomLeft;
            note.Font = UiTheme.FontUI(8F);
            note.ForeColor = UiTheme.TextTertiary;
            note.AutoSize = false;
            note.Margin = new Padding(0);
            t.Controls.Add(note, 0, 4);

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.Dock = DockStyle.Fill;
            buttons.FlowDirection = FlowDirection.LeftToRight;
            buttons.WrapContents = false;
            buttons.BackColor = UiTheme.Card;
            buttons.Margin = new Padding(0);
            buttons.Padding = new Padding(0);

            btnReadId = MakePrimaryButton("读取 Flash ID", 116);
            btnReadId.Margin = new Padding(0, 0, 8, 0);
            buttons.Controls.Add(btnReadId);

            btnEraseChip = MakeDangerButton("全片擦除", 84);
            btnEraseChip.Margin = new Padding(0);
            buttons.Controls.Add(btnEraseChip);

            t.Controls.Add(buttons, 0, 5);

            return card;
        }

        private RoundPanel BuildStatsCard()
        {
            RoundPanel card = MakeCard();

            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 1;
            t.RowCount = 3;
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 24F));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 12F));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            t.BackColor = UiTheme.Card;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);
            card.Controls.Add(t);

            t.Controls.Add(MakeCardHeader("生产统计", null), 0, 0);

            TableLayoutPanel stats = new TableLayoutPanel();
            stats.Dock = DockStyle.Fill;
            stats.ColumnCount = 3;
            stats.RowCount = 1;
            stats.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.34F));
            stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));
            stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));
            stats.BackColor = UiTheme.Card;
            stats.Margin = new Padding(0);
            stats.Padding = new Padding(0);

            Label okValue;
            Label ngValue;
            Label timeValue;

            RoundPanel ok = MakeStat("成功", out okValue, UiTheme.Success, false);
            RoundPanel ng = MakeStat("失败", out ngValue, UiTheme.Danger, false);
            RoundPanel time = MakeStat("上次用时", out timeValue, UiTheme.Text, true);

            _statOk = okValue;
            _statNg = ngValue;
            _statTime = timeValue;

            stats.Controls.Add(ok, 0, 0);
            stats.Controls.Add(ng, 1, 0);
            stats.Controls.Add(time, 2, 0);
            t.Controls.Add(stats, 0, 2);

            return card;
        }

        private RoundPanel BuildLogCard()
        {
            RoundPanel card = MakeCard();
            card.Margin = new Padding(0, 12, 0, 0);

            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 1;
            t.RowCount = 2;
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            t.BackColor = UiTheme.Card;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);
            card.Controls.Add(t);

            TableLayoutPanel header = new TableLayoutPanel();
            header.Dock = DockStyle.Fill;
            header.ColumnCount = 4;
            header.RowCount = 1;
            header.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            header.BackColor = UiTheme.Card;
            header.Margin = new Padding(0);
            header.Padding = new Padding(0);

            Label title = new Label();
            title.Text = "运行日志";
            title.Dock = DockStyle.Fill;
            title.TextAlign = ContentAlignment.MiddleLeft;
            title.Font = UiTheme.FontUI(10F, FontStyle.Bold);
            title.ForeColor = UiTheme.Text;
            title.AutoSize = false;
            title.Margin = new Padding(0);
            header.Controls.Add(title, 0, 0);

            Label legendOk = new Label();
            legendOk.Text = "● 成功";
            legendOk.AutoSize = true;
            legendOk.Font = UiTheme.FontUI(8F);
            legendOk.ForeColor = UiTheme.Success;
            legendOk.Anchor = AnchorStyles.Right;
            legendOk.Margin = new Padding(0, 0, 12, 0);
            header.Controls.Add(legendOk, 1, 0);

            Label legendWarn = new Label();
            legendWarn.Text = "● 提示";
            legendWarn.AutoSize = true;
            legendWarn.Font = UiTheme.FontUI(8F);
            legendWarn.ForeColor = UiTheme.Warning;
            legendWarn.Anchor = AnchorStyles.Right;
            legendWarn.Margin = new Padding(0, 0, 12, 0);
            header.Controls.Add(legendWarn, 2, 0);

            btnClearLog = MakeToolButton("清空", 54);
            btnClearLog.Height = 26;
            btnClearLog.Font = UiTheme.FontUI(8F);
            btnClearLog.Anchor = AnchorStyles.Right;
            btnClearLog.Margin = new Padding(0);
            header.Controls.Add(btnClearLog, 3, 0);

            t.Controls.Add(header, 0, 0);

            RoundPanel logPanel = new RoundPanel();
            logPanel.Dock = DockStyle.Fill;
            logPanel.CornerRadius = 10;
            logPanel.BorderColor = UiTheme.Border;
            logPanel.BackColor = LogBg;
            logPanel.Padding = new Padding(10, 6, 10, 6);
            logPanel.Margin = new Padding(0, 10, 0, 0);

            txtLog = new RichTextBox();
            txtLog.Dock = DockStyle.Fill;
            txtLog.ReadOnly = true;
            txtLog.BackColor = LogBg;
            txtLog.ForeColor = TextMuted;
            txtLog.Font = UiTheme.FontMono(9F);
            txtLog.BorderStyle = BorderStyle.None;
            txtLog.WordWrap = true;
            txtLog.ScrollBars = RichTextBoxScrollBars.Vertical;
            txtLog.HideSelection = false;
            txtLog.DetectUrls = false;
            txtLog.MaxLength = int.MaxValue;
            txtLog.Margin = new Padding(0);
            logPanel.Controls.Add(txtLog);

            t.Controls.Add(logPanel, 0, 1);

            return card;
        }

        private static RoundPanel MakeCard()
        {
            RoundPanel card = new RoundPanel();
            card.Dock = DockStyle.Fill;
            card.CornerRadius = 14;
            card.BorderColor = UiTheme.Border;
            card.BackColor = UiTheme.Card;
            card.Padding = new Padding(16, 14, 16, 14);
            card.Margin = new Padding(0);
            return card;
        }

        private static TableLayoutPanel MakeCardHeader(string title, PillLabel badge)
        {
            TableLayoutPanel header = new TableLayoutPanel();
            header.Dock = DockStyle.Fill;
            header.ColumnCount = 2;
            header.RowCount = 1;
            header.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            header.BackColor = UiTheme.Card;
            header.Margin = new Padding(0);
            header.Padding = new Padding(0);

            Label label = new Label();
            label.Text = title;
            label.Dock = DockStyle.Fill;
            label.TextAlign = ContentAlignment.MiddleLeft;
            label.Font = UiTheme.FontUI(10F, FontStyle.Bold);
            label.ForeColor = UiTheme.Text;
            label.AutoSize = false;
            label.Margin = new Padding(0);
            header.Controls.Add(label, 0, 0);

            if (badge != null)
            {
                badge.Anchor = AnchorStyles.Right;
                badge.Margin = new Padding(0, 1, 0, 0);
                header.Controls.Add(badge, 1, 0);
            }

            return header;
        }

        private static Label MakeFieldLabel(string text)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.Font = UiTheme.FontUI(8.5F);
            label.ForeColor = UiTheme.TextSecondary;
            label.BackColor = Color.Transparent;
            label.Anchor = AnchorStyles.Left;
            label.Margin = new Padding(0);
            return label;
        }

        private static RoundButton MakeToolButton(string text, int width)
        {
            RoundButton b = new RoundButton();
            b.Text = text;
            b.Width = width;
            b.Height = 32;
            b.CornerRadius = 9;
            b.BackColor = UiTheme.Card;
            b.ForeColor = UiTheme.Text;
            b.BorderColor = UiTheme.BorderStrong;
            b.HoverColor = Color.FromArgb(247, 247, 249);
            b.PressColor = Color.FromArgb(240, 240, 243);
            b.Font = UiTheme.FontUI(9F);
            b.Anchor = AnchorStyles.Left;
            b.Margin = new Padding(0);
            return b;
        }

        private static RoundButton MakePrimaryButton(string text, int width)
        {
            RoundButton b = new RoundButton();
            b.Text = text;
            b.Width = width;
            b.Height = 36;
            b.CornerRadius = 10;
            b.BackColor = UiTheme.Primary;
            b.ForeColor = Color.White;
            b.BorderColor = Color.Transparent;
            b.HoverColor = UiTheme.Accent;
            b.PressColor = UiTheme.Blend(UiTheme.Accent, Color.Black, 0.08);
            b.Font = UiTheme.FontUI(9F, FontStyle.Bold);
            b.Anchor = AnchorStyles.Left;
            b.Margin = new Padding(0);
            return b;
        }

        private static RoundButton MakeDangerButton(string text, int width)
        {
            RoundButton b = new RoundButton();
            b.Text = text;
            b.Width = width;
            b.Height = 36;
            b.CornerRadius = 10;
            b.BackColor = UiTheme.Card;
            b.ForeColor = UiTheme.Danger;
            b.BorderColor = Color.FromArgb(240, 189, 184);
            b.HoverColor = UiTheme.DangerSoft;
            b.PressColor = Color.FromArgb(248, 220, 217);
            b.Font = UiTheme.FontUI(9F);
            b.Anchor = AnchorStyles.Left;
            b.Margin = new Padding(0);
            return b;
        }

        private static InfoRow MakeInfoRow(string key)
        {
            InfoRow row = new InfoRow();
            row.KeyText = key;
            row.Dock = DockStyle.Fill;
            row.Margin = new Padding(0);
            return row;
        }

        private static RoundPanel MakeStat(string key, out Label value, Color valueColor, bool last)
        {
            RoundPanel panel = new RoundPanel();
            panel.Dock = DockStyle.Fill;
            panel.CornerRadius = 10;
            panel.BorderColor = Color.Transparent;
            panel.BackColor = Color.FromArgb(247, 247, 249);
            panel.Padding = new Padding(10, 8, 10, 8);
            panel.Margin = new Padding(0, 0, last ? 0 : 8, 0);

            TableLayoutPanel t = new TableLayoutPanel();
            t.Dock = DockStyle.Fill;
            t.ColumnCount = 1;
            t.RowCount = 2;
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 16F));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            t.BackColor = Color.FromArgb(247, 247, 249);
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);

            Label k = new Label();
            k.Text = key;
            k.Dock = DockStyle.Fill;
            k.TextAlign = ContentAlignment.MiddleLeft;
            k.Font = UiTheme.FontUI(8F);
            k.ForeColor = UiTheme.TextSecondary;
            k.AutoSize = false;
            k.Margin = new Padding(0);

            value = new Label();
            value.Text = "0";
            value.Dock = DockStyle.Fill;
            value.TextAlign = ContentAlignment.MiddleLeft;
            value.Font = UiTheme.FontUI(16F, FontStyle.Bold);
            value.ForeColor = valueColor;
            value.AutoSize = false;
            value.Margin = new Padding(0);

            t.Controls.Add(k, 0, 0);
            t.Controls.Add(value, 0, 1);
            panel.Controls.Add(t);

            return panel;
        }

        private void AttachDrag(Control c)
        {
            c.MouseDown += TitleBar_MouseDown;
            c.MouseMove += TitleBar_MouseMove;
            c.MouseUp += TitleBar_MouseUp;
        }

        private void TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            _dragging = true;
            _dragOffset = new Point(Cursor.Position.X - Left, Cursor.Position.Y - Top);
        }

        private void TitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_dragging) return;
            Location = new Point(Cursor.Position.X - _dragOffset.X, Cursor.Position.Y - _dragOffset.Y);
        }

        private void TitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void BindEvents()
        {
            btnRefresh.Click += delegate { RefreshPorts(); };
            btnConnect.Click += delegate { Connect(); };
            btnDisconnect.Click += delegate { Disconnect(); };
            btnReadId.Click += delegate { ReadFlashId(); };
            btnEraseChip.Click += delegate { EraseChip(); };
            btnBrowse.Click += delegate { BrowseFile(); };
            btnProgram.Click += delegate { StartProgram(); };
            btnAutoProgram.Click += delegate { StartAutoProgram(); };
            btnStop.Click += delegate { StopOperation(); };
            btnClose.Click += delegate { Close(); };
            btnClearLog.Click += delegate { txtLog.Clear(); };
            KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape)
                {
                    e.Handled = true;
                    Close();
                }
            };
            FormClosing += W25QxxForm_FormClosing;
        }

        private void RefreshPorts()
        {
            string current = cboPort.SelectedItem as string;
            if (string.IsNullOrEmpty(current)) current = _preferredPort;

            string[] names = SerialPort.GetPortNames();
            Array.Sort(names, delegate(string a, string b)
            {
                int ia = int.MaxValue;
                int ib = int.MaxValue;
                if (a != null && a.Length > 3) int.TryParse(a.Substring(3), out ia);
                if (b != null && b.Length > 3) int.TryParse(b.Substring(3), out ib);
                if (ia == ib) return string.Compare(a, b, StringComparison.OrdinalIgnoreCase);
                return ia.CompareTo(ib);
            });

            cboPort.BeginUpdate();
            cboPort.Items.Clear();
            for (int i = 0; i < names.Length; i++) cboPort.Items.Add(names[i]);

            if (current != null && cboPort.Items.Contains(current))
                cboPort.SelectedItem = current;
            else if (cboPort.Items.Count > 0)
                cboPort.SelectedIndex = 0;
            cboPort.EndUpdate();
        }

        private void Connect()
        {
            if (cboPort.SelectedItem == null)
            {
                ShowError("未检测到串口，请检查设备连接后点击“刷新”。");
                return;
            }

            string portName = cboPort.SelectedItem as string;
            try
            {
                _prog.Open(portName);
                AppendLog("已连接 " + portName + "。", OpenGreen);
            }
            catch (Exception ex)
            {
                ShowError("连接失败：\r\n" + ex.Message +
                    "\r\n\r\n如果该串口正在被主界面使用，请先关闭主界面串口。");
            }

            UpdateUiState();
        }

        private void Disconnect()
        {
            _prog.Close();
            AppendLog("串口已断开。", TextMuted);
            UpdateUiState();
        }

        private void ReadFlashId()
        {
            RunOperation("读取 Flash ID", delegate
            {
                W25QxxFlashInfo info = _prog.ReadId(LogAsync);
                SetFlashInfoAsync(info);
                SetStatusAsync("Flash ID 读取完成", OpenGreen);
            });
        }

        private void EraseChip()
        {
            DialogResult r = MessageBox.Show(this,
                "全片擦除会清空整个 Flash，确定吗？",
                "W25Qxx Flash 烧录工具",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r != DialogResult.Yes) return;

            RunOperation("全片擦除", delegate
            {
                SetProgressAsync("全片擦除中...", 0, 0);
                _prog.EraseChip(LogAsync);
                SetProgressSuccessAsync("全片擦除完成");
            });
        }

        private void BrowseFile()
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "选择固件文件";
                dlg.Filter = "BIN 文件 (*.bin)|*.bin|所有文件 (*.*)|*.*";

                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    _fileData = File.ReadAllBytes(dlg.FileName);
                    _lblFileName.Text = Path.GetFileName(dlg.FileName);
                    _lblFileMeta.Text = FormatSize(_fileData.Length) + " · " + dlg.FileName;
                    AppendLog(string.Format("已选择文件：{0}，大小 {1}。",
                        Path.GetFileName(dlg.FileName), FormatSize(_fileData.Length)), TextDark);
                }
                catch (Exception ex)
                {
                    _fileData = null;
                    _lblFileName.Text = "未选择固件文件";
                    _lblFileMeta.Text = "请选择 .bin 固件文件";
                    ShowError("读取文件失败：\r\n" + ex.Message);
                }
            }

            UpdateUiState();
        }

        private static string FormatSize(long bytes)
        {
            if (bytes >= 1024L * 1024L)
                return string.Format(CultureInfo.InvariantCulture, "{0:F2} MB ({1} 字节)", bytes / 1024.0 / 1024.0, bytes);
            if (bytes >= 1024L)
                return string.Format(CultureInfo.InvariantCulture, "{0:F1} KB ({1} 字节)", bytes / 1024.0, bytes);
            return bytes.ToString(CultureInfo.InvariantCulture) + " 字节";
        }

        private void StartProgram()
        {
            byte[] data;
            uint startAddr;
            if (!TryGetProgramInput(out data, out startAddr)) return;

            if (!_prog.IsOpen)
            {
                ShowError("请先连接设备。");
                return;
            }

            bool doVerify = chkVerify.Checked;
            DateTime started = DateTime.UtcNow;

            RunOperation("烧写", delegate
            {
                SetProgressAsync("读取 Flash ID...", 0, 0);
                _prog.ProgramFile(data, startAddr, doVerify, LogAsync, ProgressAsync);
                _lastDurationText = (DateTime.UtcNow - started).TotalSeconds.ToString("F1", CultureInfo.InvariantCulture) + " s";
                UpdateCountersAsync();
                SetProgressSuccessAsync("烧写成功");
            });
        }

        private bool TryGetProgramInput(out byte[] data, out uint startAddr)
        {
            data = null;
            startAddr = 0;

            if (_fileData == null || _fileData.Length == 0)
            {
                ShowError("请先选择固件文件。");
                return false;
            }

            if (!TryParseAddress(txtStartAddr.Text, out startAddr))
            {
                ShowError("起始地址格式错误，请输入十六进制地址，例如 0 或 0x1000。");
                return false;
            }

            data = _fileData;
            return true;
        }

        private void StartAutoProgram()
        {
            if (_busy) return;

            byte[] data;
            uint startAddr;
            if (!TryGetProgramInput(out data, out startAddr)) return;

            if (!_prog.IsOpen)
            {
                string portName = cboPort.SelectedItem as string;
                if (string.IsNullOrEmpty(portName))
                {
                    ShowError("未检测到串口，请检查设备连接后点击“刷新”。");
                    return;
                }

                try
                {
                    _prog.Open(portName);
                    AppendLog("已自动连接 " + portName + "。", OpenGreen);
                }
                catch (Exception ex)
                {
                    ShowError("自动连接失败：\r\n" + ex.Message +
                        "\r\n\r\n如果该串口正在被主界面使用，请先关闭主界面串口。");
                    UpdateUiState();
                    return;
                }
            }

            bool continuous = chkContinuous.Checked;
            bool doVerify = chkVerify.Checked;

            _okCount = 0;
            _ngCount = 0;
            _lastDurationText = "—";
            UpdateCounters();

            _busy = true;
            _prog.ResetAbort();
            ResetProgress();
            UpdateUiState();

            AppendLog("===== 全自动烧录开始 =====", Accent);
            if (continuous)
            {
                AppendLog("连续模式：烧录成功后请取走芯片，检测到新芯片会自动开始下一片。", TextMuted);
            }

            Thread t = new Thread(delegate()
            {
                int index = 0;
                try
                {
                    if (continuous)
                    {
                        WaitForChipPresent(true);
                    }

                    while (true)
                    {
                        index++;
                        LogAsync(string.Format("----- 第 {0} 片开始烧录 -----", index), TextDark);

                        try
                        {
                            DateTime started = DateTime.UtcNow;
                            _prog.ProgramFile(data, startAddr, doVerify, LogAsync, ProgressAsync);
                            _okCount++;
                            _lastDurationText = (DateTime.UtcNow - started).TotalSeconds.ToString("F1", CultureInfo.InvariantCulture) + " s";
                            UpdateCountersAsync();
                            LogAsync(string.Format("第 {0} 片烧录成功。成功 {1} 片，失败 {2} 片。",
                                index, _okCount, _ngCount), OpenGreen);
                            SetProgressSuccessAsync("烧录成功");
                        }
                        catch (OperationCanceledException)
                        {
                            throw;
                        }
                        catch (Exception ex)
                        {
                            _ngCount++;
                            UpdateCountersAsync();

                            if (!continuous) throw;

                            LogAsync("第 " + index + " 片烧录失败：" + ex.Message, UiTheme.Danger);
                            LogAsync(string.Format("成功 {0} 片，失败 {1} 片。", _okCount, _ngCount), UiTheme.Danger);
                            SetProgressFailedAsync("烧录失败");
                        }

                        if (!continuous) break;

                        LogAsync("请取走芯片，等待检测新芯片...", TextMuted);
                        SetProgressAsync("请取走芯片...", 0, 0);
                        WaitForChipRemoved();
                        SetProgressAsync("等待放入新芯片...", 0, 0);
                        WaitForChipPresent(false);
                    }

                    LogAsync(string.Format("===== 全自动烧录完成：成功 {0} 片，失败 {1} 片 =====",
                        _okCount, _ngCount), OpenGreen);
                }
                catch (OperationCanceledException)
                {
                    LogAsync("全自动烧录已停止。", UiTheme.Warning);
                    LogAsync(string.Format("本次成功 {0} 片，失败 {1} 片。", _okCount, _ngCount), UiTheme.Warning);
                    SetStatusAsync("已停止", UiTheme.Warning);
                }
                catch (Exception ex)
                {
                    LogAsync("全自动烧录失败：" + ex.Message, UiTheme.Danger);
                    LogAsync(string.Format("本次成功 {0} 片，失败 {1} 片。", _okCount, _ngCount), UiTheme.Danger);
                    SetProgressFailedAsync("全自动烧录失败");
                }
                finally
                {
                    try
                    {
                        BeginInvoke(new Action(delegate
                        {
                            _busy = false;
                            UpdateUiState();
                        }));
                    }
                    catch { }
                }
            });

            t.IsBackground = true;
            t.Start();
        }

        private void StopOperation()
        {
            if (!_busy) return;
            _prog.Abort();
            AppendLog("正在停止当前操作...", UiTheme.Warning);
        }

        private void WaitForChipRemoved()
        {
            int absent = 0;
            while (true)
            {
                _prog.ThrowIfAborted();
                W25QxxFlashInfo info = _prog.TryReadId(600);
                if (info == null)
                {
                    absent++;
                    if (absent >= 2)
                    {
                        LogAsync("已检测到芯片取走。", TextMuted);
                        return;
                    }
                }
                else
                {
                    absent = 0;
                }

                SleepWithAbort(200);
            }
        }

        private void WaitForChipPresent(bool initial)
        {
            W25QxxFlashInfo info = _prog.TryReadId(800);
            if (info != null) return;

            LogAsync(initial ? "未检测到芯片，等待放入芯片..." : "等待放入新芯片...", TextMuted);

            while (true)
            {
                _prog.ThrowIfAborted();
                info = _prog.TryReadId(800);
                if (info != null) return;
                SleepWithAbort(200);
            }
        }

        private void SleepWithAbort(int ms)
        {
            DateTime end = DateTime.UtcNow.AddMilliseconds(ms);
            while (DateTime.UtcNow < end)
            {
                _prog.ThrowIfAborted();
                Thread.Sleep(20);
            }
        }

        private void UpdateCounters()
        {
            _statOk.Text = _okCount.ToString(CultureInfo.InvariantCulture);
            _statNg.Text = _ngCount.ToString(CultureInfo.InvariantCulture);
            _statTime.Text = _lastDurationText;
        }

        private void UpdateCountersAsync()
        {
            int ok = _okCount;
            int ng = _ngCount;
            string duration = _lastDurationText;
            try
            {
                BeginInvoke(new Action(delegate
                {
                    _statOk.Text = ok.ToString(CultureInfo.InvariantCulture);
                    _statNg.Text = ng.ToString(CultureInfo.InvariantCulture);
                    _statTime.Text = duration;
                }));
            }
            catch { }
        }

        private static bool TryParseAddress(string text, out uint value)
        {
            value = 0;
            if (text == null) return true;

            string s = text.Trim();
            if (s.Length == 0) return true;
            if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase)) s = s.Substring(2);
            if (s.Length == 0) return false;

            return uint.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out value);
        }

        private void RunOperation(string title, Action work)
        {
            if (_busy) return;
            if (!_prog.IsOpen)
            {
                ShowError("串口未连接。");
                return;
            }

            _busy = true;
            _prog.ResetAbort();
            ResetProgress();
            UpdateUiState();

            Thread t = new Thread(delegate()
            {
                try
                {
                    work();
                }
                catch (OperationCanceledException)
                {
                    LogAsync("操作已取消。", UiTheme.Warning);
                    SetStatusAsync(title + "已取消", UiTheme.Warning);
                }
                catch (Exception ex)
                {
                    LogAsync(title + "失败：" + ex.Message, UiTheme.Danger);
                    SetProgressFailedAsync(title + "失败");
                }
                finally
                {
                    try
                    {
                        BeginInvoke(new Action(delegate
                        {
                            _busy = false;
                            UpdateUiState();
                        }));
                    }
                    catch { }
                }
            });

            t.IsBackground = true;
            t.Start();
        }

        private void UpdateUiState()
        {
            bool open = _prog.IsOpen;
            bool busy = _busy;

            cboPort.Enabled = !open && !busy;
            btnRefresh.Enabled = !open && !busy;
            btnConnect.Enabled = !open && !busy;
            btnDisconnect.Enabled = open && !busy;
            btnReadId.Enabled = open && !busy;
            btnEraseChip.Enabled = open && !busy;
            btnBrowse.Enabled = !busy;
            txtStartAddr.Enabled = !busy;
            chkVerify.Enabled = !busy;
            btnProgram.Enabled = open && _fileData != null && !busy;
            btnAutoProgram.Enabled = _fileData != null && !busy;
            chkContinuous.Enabled = !busy;
            btnStop.Enabled = busy;
            btnClearLog.Enabled = true;

            SetConnPill(open, _prog.PortName);
        }

        private void SetConnPill(bool open, string port)
        {
            if (_connPill == null) return;

            if (open)
            {
                _connPill.SetStyle("已连接 " + port,
                    UiTheme.SuccessSoft, Color.FromArgb(191, 227, 191),
                    UiTheme.Success, UiTheme.Success);
            }
            else
            {
                _connPill.SetStyle("未连接",
                    Color.FromArgb(245, 245, 247), UiTheme.Border,
                    UiTheme.TextSecondary, UiTheme.TextTertiary);
            }
        }

        private void SetStatePill(string text, int kind)
        {
            if (_statePill == null) return;

            Color fill;
            Color border;
            Color fore;

            if (kind == 1)
            {
                fill = UiTheme.PrimarySoft;
                border = Color.FromArgb(243, 199, 154);
                fore = UiTheme.Accent;
            }
            else if (kind == 2)
            {
                fill = UiTheme.SuccessSoft;
                border = Color.FromArgb(191, 227, 191);
                fore = UiTheme.Success;
            }
            else if (kind == 3)
            {
                fill = UiTheme.DangerSoft;
                border = Color.FromArgb(240, 189, 184);
                fore = UiTheme.Danger;
            }
            else
            {
                fill = Color.FromArgb(245, 245, 247);
                border = UiTheme.Border;
                fore = UiTheme.TextSecondary;
            }

            _statePill.SetStyle(text, fill, border, fore, Color.Empty);
        }

        private void SetIdPill(string text, int kind)
        {
            if (_idPill == null) return;

            if (kind == 2)
            {
                _idPill.SetStyle(text, UiTheme.SuccessSoft, Color.FromArgb(191, 227, 191),
                    UiTheme.Success, Color.Empty);
            }
            else if (kind == 3)
            {
                _idPill.SetStyle(text, UiTheme.DangerSoft, Color.FromArgb(240, 189, 184),
                    UiTheme.Danger, Color.Empty);
            }
            else
            {
                _idPill.SetStyle(text, Color.FromArgb(245, 245, 247), UiTheme.Border,
                    UiTheme.TextSecondary, Color.Empty);
            }
        }

        private void ResetProgress()
        {
            _progress.Marquee = false;
            _progress.Value = 0;
            _progress.BarColor = UiTheme.Primary;
            _lblProgLabel.Text = "等待开始";
            _lblProgLabel.ForeColor = UiTheme.TextTertiary;
            _lblProgPct.Text = "0%";
            _steps.SetStage(-1, false, false);
            SetStatePill("就绪", 0);

            _lastProgressStage = null;
            _lastProgressPercent = -1;
            _lastProgressTick = 0;
        }

        private void ProgressAsync(string stage, int cur, int total)
        {
            int pct = total > 0 ? (int)((long)cur * 100L / (long)total) : -1;
            if (pct > 100) pct = 100;
            if (pct < 0) pct = 0;

            int now = Environment.TickCount;
            if (stage == _lastProgressStage &&
                pct == _lastProgressPercent &&
                now - _lastProgressTick < 200)
            {
                return;
            }

            _lastProgressStage = stage;
            _lastProgressPercent = pct;
            _lastProgressTick = now;

            try
            {
                BeginInvoke(new Action(delegate { UpdateProgress(stage, cur, total); }));
            }
            catch { }
        }

        private void UpdateProgress(string stage, int cur, int total)
        {
            _lblProgLabel.Text = stage;
            _lblProgLabel.ForeColor = UiTheme.TextSecondary;

            int stageIndex;
            bool completed;
            if (stage != null && stage.IndexOf("完成", StringComparison.Ordinal) >= 0)
            {
                stageIndex = 3;
                completed = true;
            }
            else if (stage != null && stage.IndexOf("擦除", StringComparison.Ordinal) >= 0)
            {
                stageIndex = 1;
                completed = false;
            }
            else if (stage != null && stage.IndexOf("写入", StringComparison.Ordinal) >= 0)
            {
                stageIndex = 2;
                completed = false;
            }
            else if (stage != null && stage.IndexOf("校验", StringComparison.Ordinal) >= 0)
            {
                stageIndex = 3;
                completed = false;
            }
            else
            {
                stageIndex = 0;
                completed = false;
            }
            _steps.SetStage(stageIndex, completed, false);
            SetStatePill(completed ? "完成" : "烧写中", completed ? 2 : 1);

            if (total <= 0)
            {
                _progress.Marquee = true;
                _lblProgPct.Text = "…";
            }
            else
            {
                _progress.Marquee = false;

                int pct = (int)((long)cur * 100L / (long)total);
                if (pct < 0) pct = 0;
                if (pct > 100) pct = 100;
                _progress.Value = pct;
                _lblProgPct.Text = pct.ToString(CultureInfo.InvariantCulture) + "%";
            }
        }

        private void SetProgressAsync(string stage, int cur, int total)
        {
            try
            {
                BeginInvoke(new Action(delegate { UpdateProgress(stage, cur, total); }));
            }
            catch { }
        }

        private void SetStatusAsync(string text, Color color)
        {
            try
            {
                BeginInvoke(new Action(delegate
                {
                    _progress.Marquee = false;
                    _progress.Value = 0;
                    _lblProgPct.Text = "0%";
                    _lblProgLabel.Text = text;
                    _lblProgLabel.ForeColor = color;

                    if (color == OpenGreen) SetStatePill("就绪", 2);
                    else if (color == UiTheme.Danger) SetStatePill("异常", 3);
                    else SetStatePill("已停止", 0);
                }));
            }
            catch { }
        }

        private void SetProgressSuccessAsync(string text)
        {
            try
            {
                BeginInvoke(new Action(delegate
                {
                    _progress.Marquee = false;
                    _progress.Value = 100;
                    _progress.BarColor = UiTheme.Success;
                    _lblProgPct.Text = "100%";
                    _lblProgLabel.Text = text;
                    _lblProgLabel.ForeColor = OpenGreen;
                    _steps.SetStage(3, true, false);
                    SetStatePill("成功", 2);
                }));
            }
            catch { }
        }

        private void SetProgressFailedAsync(string text)
        {
            try
            {
                BeginInvoke(new Action(delegate
                {
                    _progress.Marquee = false;
                    _progress.Value = 0;
                    _progress.BarColor = UiTheme.Danger;
                    _lblProgPct.Text = "0%";
                    _lblProgLabel.Text = text;
                    _lblProgLabel.ForeColor = UiTheme.Danger;
                    _steps.SetStage(_steps.Stage, false, true);
                    SetStatePill("失败", 3);
                }));
            }
            catch { }
        }

        private void SetFlashInfoAsync(W25QxxFlashInfo info)
        {
            try
            {
                BeginInvoke(new Action(delegate
                {
                    byte vendorId = (byte)((info.JedecId >> 16) & 0xFF);

                    _rowModel.SetValue(info.Model);
                    _rowManu.SetValue(string.Format("0x{0:X2} · {1}", vendorId, info.Vendor));
                    _rowDev.SetValue(string.Format("0x{0:X6}", info.JedecId));
                    _rowSize.SetValue(string.Format(CultureInfo.InvariantCulture,
                        "{0:F2} MB ({1:F0} Mbit)", info.Capacity / 1024.0 / 1024.0, info.Capacity / 1024.0 / 1024.0 * 8.0));
                    _rowPage.SetValue("256 B / 4 KB");

                    SetIdPill("已识别", 2);
                }));
            }
            catch { }
        }

        private void AppendLog(string msg, Color color)
        {
            if (txtLog.TextLength > 200000) txtLog.Clear();

            string line = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + msg + Environment.NewLine;

            txtLog.SelectionStart = txtLog.TextLength;
            txtLog.SelectionLength = 0;
            txtLog.SelectionColor = color;
            txtLog.AppendText(line);
            txtLog.SelectionColor = TextDark;
            txtLog.SelectionStart = txtLog.TextLength;
            txtLog.ScrollToCaret();
        }

        private void LogAsync(string msg)
        {
            LogAsync(msg, TextDark);
        }

        private void LogAsync(string msg, Color color)
        {
            try
            {
                BeginInvoke(new Action(delegate { AppendLog(msg, color); }));
            }
            catch { }
        }

        private void ShowError(string message)
        {
            MessageBox.Show(this, message, "W25Qxx Flash 烧录工具",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void W25QxxForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_busy)
            {
                DialogResult r = MessageBox.Show(this,
                    "操作正在进行，确定要中止并关闭吗？",
                    "W25Qxx Flash 烧录工具",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (r != DialogResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }

                _prog.Abort();
            }

            _prog.Close();

            if (_tip != null)
            {
                _tip.Dispose();
                _tip = null;
            }
        }
    }
}
