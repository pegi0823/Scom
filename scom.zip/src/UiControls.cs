using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Scom
{
    public static class UiTheme
    {
        public static readonly Color Background = Color.FromArgb(244, 244, 246);
        public static readonly Color Card = Color.White;
        public static readonly Color PanelBg = Color.FromArgb(254, 253, 252);
        public static readonly Color InputBg = Color.FromArgb(248, 248, 250);
        public static readonly Color Primary = Color.FromArgb(243, 160, 76);
        public static readonly Color Accent = Color.FromArgb(229, 133, 34);
        public static readonly Color PrimarySoft = Color.FromArgb(252, 235, 221);
        public static readonly Color Success = Color.FromArgb(64, 180, 62);
        public static readonly Color SuccessSoft = Color.FromArgb(232, 246, 232);
        public static readonly Color Warning = Color.FromArgb(235, 164, 0);
        public static readonly Color Danger = Color.FromArgb(230, 92, 83);
        public static readonly Color DangerSoft = Color.FromArgb(252, 232, 230);
        public static readonly Color Text = Color.FromArgb(51, 51, 51);
        public static readonly Color TextSecondary = Color.FromArgb(128, 128, 128);
        public static readonly Color TextTertiary = Color.FromArgb(166, 166, 166);
        public static readonly Color Border = Color.FromArgb(236, 236, 239);
        public static readonly Color BorderStrong = Color.FromArgb(220, 220, 225);
        public static readonly Color LogBg = Color.FromArgb(250, 250, 251);
        public static readonly Color Blue = Color.FromArgb(88, 178, 220);
        public static readonly Color BlueSoft = Color.FromArgb(232, 244, 250);

        public static Font FontUI(float size)
        {
            return new Font("Microsoft YaHei UI", size, FontStyle.Regular, GraphicsUnit.Point);
        }

        public static Font FontUI(float size, FontStyle style)
        {
            return new Font("Microsoft YaHei UI", size, style, GraphicsUnit.Point);
        }

        public static Font FontMono(float size)
        {
            return new Font("Consolas", size, FontStyle.Regular, GraphicsUnit.Point);
        }

        public static Font FontMono(float size, FontStyle style)
        {
            return new Font("Consolas", size, style, GraphicsUnit.Point);
        }

        public static Color Blend(Color a, Color b, double t)
        {
            if (t < 0) t = 0;
            if (t > 1) t = 1;
            return Color.FromArgb(
                (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        public static GraphicsPath RoundedRect(RectangleF rect, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            if (radius <= 0.5F)
            {
                path.AddRectangle(rect);
                return path;
            }

            float r = Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2F);
            if (r <= 0.5F)
            {
                path.AddRectangle(rect);
                return path;
            }

            path.AddArc(rect.X, rect.Y, r * 2F, r * 2F, 180F, 90F);
            path.AddArc(rect.Right - r * 2F, rect.Y, r * 2F, r * 2F, 270F, 90F);
            path.AddArc(rect.Right - r * 2F, rect.Bottom - r * 2F, r * 2F, r * 2F, 0F, 90F);
            path.AddArc(rect.X, rect.Bottom - r * 2F, r * 2F, r * 2F, 90F, 90F);
            path.CloseFigure();
            return path;
        }
    }

    public class RoundPanel : Panel
    {
        private Region _roundRegion;

        public int CornerRadius { get; set; }
        public Color BorderColor { get; set; }

        public RoundPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
            DoubleBuffered = true;
            CornerRadius = 14;
            BorderColor = UiTheme.Border;
            BackColor = UiTheme.Card;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            UpdateRegion();
        }

        private void UpdateRegion()
        {
            if (Width <= 0 || Height <= 0) return;

            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0, 0, Width, Height), CornerRadius))
            {
                Region region = new Region(path);
                Region old = _roundRegion;
                _roundRegion = region;
                Region = region;
                if (old != null) old.Dispose();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (BorderColor.A == 0) return;

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0.5F, 0.5F, Width - 1F, Height - 1F), CornerRadius))
            using (Pen pen = new Pen(BorderColor, 1F))
            {
                e.Graphics.DrawPath(pen, path);
            }
        }
    }

    public class RoundButton : Button
    {
        private bool _hover;
        private bool _pressed;
        private Region _roundRegion;

        public int CornerRadius { get; set; }
        public Color HoverColor { get; set; }
        public Color PressColor { get; set; }
        public Color BorderColor { get; set; }

        public RoundButton()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor |
                     ControlStyles.Selectable, false);
            DoubleBuffered = true;
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            Cursor = Cursors.Hand;
            TabStop = false;
            NotifyDefault(false);
            Height = 32;
            CornerRadius = 9;
            BackColor = Color.White;
            ForeColor = UiTheme.Text;
            Font = UiTheme.FontUI(9F);
            BorderColor = Color.Transparent;
            HoverColor = Color.Empty;
            PressColor = Color.Empty;
        }

        protected override bool ShowFocusCues
        {
            get { return false; }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            UpdateRegion();
        }

        private void UpdateRegion()
        {
            if (Width <= 0 || Height <= 0) return;

            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0, 0, Width, Height), CornerRadius))
            {
                Region region = new Region(path);
                Region old = _roundRegion;
                _roundRegion = region;
                Region = region;
                if (old != null) old.Dispose();
            }
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hover = false;
            _pressed = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) _pressed = true;
            Invalidate();
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            _pressed = false;
            Invalidate();
            base.OnMouseUp(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            Invalidate();
            base.OnEnabledChanged(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            Color fill;
            Color textColor;
            Color borderColor = BorderColor;

            if (!Enabled)
            {
                fill = UiTheme.Blend(BackColor, Color.White, 0.55);
                textColor = UiTheme.TextTertiary;
                if (BorderColor.A > 0) borderColor = UiTheme.Blend(BorderColor, Color.White, 0.55);
            }
            else
            {
                fill = BackColor;
                if (_hover)
                {
                    if (HoverColor.A > 0) fill = HoverColor;
                    else fill = UiTheme.Blend(BackColor, Color.Black, 0.06);
                }
                if (_pressed)
                {
                    if (PressColor.A > 0) fill = PressColor;
                    else fill = UiTheme.Blend(fill, Color.Black, 0.08);
                }
                textColor = ForeColor;
            }

            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0, 0, Width, Height), CornerRadius))
            using (SolidBrush brush = new SolidBrush(fill))
            {
                e.Graphics.FillPath(brush, path);
                if (borderColor.A > 0)
                {
                    using (Pen pen = new Pen(borderColor, 1F))
                    {
                        e.Graphics.DrawPath(pen, path);
                    }
                }
            }

            TextFormatFlags flags = TextFormatFlags.HorizontalCenter |
                                    TextFormatFlags.VerticalCenter |
                                    TextFormatFlags.NoPadding |
                                    TextFormatFlags.EndEllipsis;
            TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle, textColor, flags);
        }
    }

    public class PillLabel : Control
    {
        private Region _roundRegion;

        public int CornerRadius { get; set; }
        public Color FillColor { get; set; }
        public Color BorderColor { get; set; }
        public Color DotColor { get; set; }
        public int HorizontalPadding { get; set; }

        public PillLabel()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            BackColor = Color.Transparent;
            Font = UiTheme.FontUI(8.5F);
            ForeColor = UiTheme.TextSecondary;
            FillColor = Color.FromArgb(245, 245, 247);
            BorderColor = UiTheme.Border;
            DotColor = Color.Empty;
            HorizontalPadding = 9;
            CornerRadius = 11;
            Height = 22;
        }

        public void SetStyle(string text, Color fill, Color border, Color fore, Color dot)
        {
            FillColor = fill;
            BorderColor = border;
            ForeColor = fore;
            DotColor = dot;
            Text = text;
            UpdateSize();
            Invalidate();
        }

        public void RefreshSize()
        {
            UpdateSize();
            Invalidate();
        }

        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);
            UpdateSize();
            Invalidate();
        }

        protected override void OnFontChanged(EventArgs e)
        {
            base.OnFontChanged(e);
            UpdateSize();
            Invalidate();
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            UpdateRegion();
        }

        private void UpdateSize()
        {
            Size textSize = TextRenderer.MeasureText(Text, Font);
            int dotWidth = DotColor.IsEmpty ? 0 : 11;
            int width = textSize.Width + HorizontalPadding * 2 + dotWidth;
            int height = Math.Max(22, textSize.Height + 6);
            if (Width != width || Height != height) Size = new Size(width, height);
            UpdateRegion();
        }

        private void UpdateRegion()
        {
            if (Width <= 0 || Height <= 0) return;

            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0, 0, Width, Height), CornerRadius))
            {
                Region region = new Region(path);
                Region old = _roundRegion;
                _roundRegion = region;
                Region = region;
                if (old != null) old.Dispose();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            using (GraphicsPath path = UiTheme.RoundedRect(
                new RectangleF(0, 0, Width, Height), CornerRadius))
            using (SolidBrush brush = new SolidBrush(FillColor))
            {
                e.Graphics.FillPath(brush, path);
                if (BorderColor.A > 0)
                {
                    using (Pen pen = new Pen(BorderColor, 1F))
                    {
                        e.Graphics.DrawPath(pen, path);
                    }
                }
            }

            int textX = HorizontalPadding;
            if (!DotColor.IsEmpty)
            {
                int dotSize = 5;
                int dotY = (Height - dotSize) / 2;
                using (SolidBrush dotBrush = new SolidBrush(DotColor))
                {
                    e.Graphics.FillEllipse(dotBrush, HorizontalPadding, dotY, dotSize, dotSize);
                }
                textX += 11;
            }

            TextFormatFlags flags = TextFormatFlags.Left |
                                    TextFormatFlags.VerticalCenter |
                                    TextFormatFlags.NoPadding |
                                    TextFormatFlags.EndEllipsis;
            Rectangle textRect = new Rectangle(textX, 0, Width - textX - HorizontalPadding, Height);
            TextRenderer.DrawText(e.Graphics, Text, Font, textRect, ForeColor, flags);
        }
    }

    public class RoundCheckBox : Control
    {
        private bool _checked;
        private bool _hover;

        public event EventHandler CheckedChanged;

        public bool Checked
        {
            get { return _checked; }
            set
            {
                if (_checked == value) return;
                _checked = value;
                Invalidate();
                if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty);
            }
        }

        public RoundCheckBox()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.Selectable, true);
            DoubleBuffered = true;
            AutoSize = true;
            Height = 22;
            BackColor = UiTheme.Card;
            ForeColor = UiTheme.TextSecondary;
            Font = UiTheme.FontUI(9F);
            Cursor = Cursors.Hand;
            TabStop = true;
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            Size textSize = TextRenderer.MeasureText(Text, Font);
            return new Size(20 + textSize.Width + 2, Math.Max(22, textSize.Height + 4));
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hover = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnClick(EventArgs e)
        {
            if (Enabled)
            {
                Checked = !Checked;
                Focus();
            }
            base.OnClick(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                Checked = !Checked;
                e.Handled = true;
            }
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            int boxSize = 14;
            int boxY = (Height - boxSize) / 2;
            Rectangle boxRect = new Rectangle(0, boxY, boxSize, boxSize);

            Color borderColor;
            Color fillColor;
            Color foreColor;

            if (!Enabled)
            {
                borderColor = Color.FromArgb(220, 220, 224);
                fillColor = Color.FromArgb(245, 245, 247);
                foreColor = UiTheme.TextTertiary;
            }
            else
            {
                borderColor = Checked ? UiTheme.Primary : (_hover ? UiTheme.Primary : Color.FromArgb(201, 201, 206));
                fillColor = Checked ? UiTheme.Primary : Color.White;
                foreColor = ForeColor;
            }

            using (GraphicsPath path = UiTheme.RoundedRect(boxRect, 4F))
            using (SolidBrush brush = new SolidBrush(fillColor))
            using (Pen pen = new Pen(borderColor, 1F))
            {
                e.Graphics.FillPath(brush, path);
                e.Graphics.DrawPath(pen, path);
            }

            if (Checked)
            {
                using (Pen checkPen = new Pen(Enabled ? Color.White : Color.FromArgb(190, 190, 195), 2F))
                {
                    checkPen.StartCap = LineCap.Round;
                    checkPen.EndCap = LineCap.Round;
                    e.Graphics.DrawLines(checkPen, new PointF[]
                    {
                        new PointF(3.5F, boxY + 7F),
                        new PointF(6F, boxY + 9.5F),
                        new PointF(10.5F, boxY + 4.5F)
                    });
                }
            }

            TextFormatFlags flags = TextFormatFlags.Left |
                                    TextFormatFlags.VerticalCenter |
                                    TextFormatFlags.NoPadding |
                                    TextFormatFlags.EndEllipsis;
            Rectangle textRect = new Rectangle(20, 0, Width - 20, Height);
            TextRenderer.DrawText(e.Graphics, Text, Font, textRect, foreColor, flags);

            if (Focused && ShowFocusCues)
            {
                Rectangle focusRect = new Rectangle(19, 2, Math.Max(0, Width - 21), Math.Max(0, Height - 5));
                ControlPaint.DrawFocusRectangle(e.Graphics, focusRect);
            }
        }
    }

    public class StepChips : Control
    {
        private static readonly string[] StepLabels = new string[]
        {
            "读取 ID", "擦除", "写入", "校验"
        };

        public int Stage { get; set; }
        public bool Completed { get; set; }
        public bool Failed { get; set; }

        public StepChips()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            BackColor = Color.Transparent;
            Font = UiTheme.FontUI(8F);
            Height = 22;
            Stage = -1;
        }

        public void SetStage(int stage, bool completed, bool failed)
        {
            Stage = stage;
            Completed = completed;
            Failed = failed;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            int x = 0;
            for (int i = 0; i < StepLabels.Length; i++)
            {
                string label = StepLabels[i];
                Size textSize = TextRenderer.MeasureText(label, Font);
                int chipWidth = textSize.Width + 16;
                Rectangle chipRect = new Rectangle(x, 1, chipWidth, 20);

                Color fill = Color.Transparent;
                Color border = UiTheme.Border;
                Color fore = UiTheme.TextTertiary;

                if (Completed || i < Stage)
                {
                    fill = UiTheme.SuccessSoft;
                    border = Color.FromArgb(191, 227, 191);
                    fore = UiTheme.Success;
                }
                else if (Failed && i == Stage)
                {
                    fill = UiTheme.DangerSoft;
                    border = Color.FromArgb(240, 189, 184);
                    fore = UiTheme.Danger;
                }
                else if (i == Stage)
                {
                    fill = UiTheme.PrimarySoft;
                    border = Color.FromArgb(243, 199, 154);
                    fore = UiTheme.Accent;
                }

                using (GraphicsPath path = UiTheme.RoundedRect(chipRect, 10F))
                {
                    if (fill.A > 0)
                    {
                        using (SolidBrush brush = new SolidBrush(fill))
                        {
                            e.Graphics.FillPath(brush, path);
                        }
                    }
                    using (Pen pen = new Pen(border, 1F))
                    {
                        e.Graphics.DrawPath(pen, path);
                    }
                }

                TextFormatFlags flags = TextFormatFlags.HorizontalCenter |
                                        TextFormatFlags.VerticalCenter |
                                        TextFormatFlags.NoPadding;
                TextRenderer.DrawText(e.Graphics, label, Font, chipRect, fore, flags);

                x += chipWidth + 6;
            }
        }
    }

    public class SlimProgress : Control
    {
        private int _value;
        private bool _marquee;
        private int _offset;
        private readonly Timer _timer;

        public int Value
        {
            get { return _value; }
            set
            {
                int v = value;
                if (v < 0) v = 0;
                if (v > 100) v = 100;
                if (_value != v)
                {
                    _value = v;
                    Invalidate();
                }
            }
        }

        public bool Marquee
        {
            get { return _marquee; }
            set
            {
                if (_marquee == value) return;
                _marquee = value;
                if (_marquee)
                {
                    _offset = 0;
                    _timer.Start();
                }
                else
                {
                    _timer.Stop();
                }
                Invalidate();
            }
        }

        public Color BarColor { get; set; }
        public Color TrackColor { get; set; }

        public SlimProgress()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            BackColor = Color.Transparent;
            Height = 10;
            BarColor = UiTheme.Primary;
            TrackColor = Color.FromArgb(233, 233, 237);

            _timer = new Timer();
            _timer.Interval = 30;
            _timer.Tick += delegate
            {
                _offset += 2;
                if (_offset > 100) _offset = 0;
                Invalidate();
            };
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            float trackHeight = 6F;
            float y = (Height - trackHeight) / 2F;
            RectangleF trackRect = new RectangleF(0, y, Width, trackHeight);

            using (GraphicsPath trackPath = UiTheme.RoundedRect(trackRect, 3F))
            {
                using (SolidBrush trackBrush = new SolidBrush(TrackColor))
                {
                    e.Graphics.FillPath(trackBrush, trackPath);
                }

                if (_marquee)
                {
                    GraphicsState state = e.Graphics.Save();
                    e.Graphics.SetClip(trackPath);
                    float segmentWidth = Math.Max(44F, Width * 0.28F);
                    float x = (_offset / 100F) * (Width + segmentWidth) - segmentWidth;
                    RectangleF segmentRect = new RectangleF(x, y, segmentWidth, trackHeight);
                    using (GraphicsPath segmentPath = UiTheme.RoundedRect(segmentRect, 3F))
                    using (SolidBrush segmentBrush = new SolidBrush(BarColor))
                    {
                        e.Graphics.FillPath(segmentBrush, segmentPath);
                    }
                    e.Graphics.Restore(state);
                }
                else if (_value > 0)
                {
                    float fillWidth = Width * (_value / 100F);
                    if (fillWidth < 6F) fillWidth = 6F;
                    RectangleF fillRect = new RectangleF(0, y, fillWidth, trackHeight);
                    using (GraphicsPath fillPath = UiTheme.RoundedRect(fillRect, 3F))
                    using (SolidBrush fillBrush = new SolidBrush(BarColor))
                    {
                        e.Graphics.FillPath(fillBrush, fillPath);
                    }
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _timer.Stop();
                _timer.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    public class InfoRow : Control
    {
        private string _valueText;

        public string KeyText { get; set; }
        public bool ShowSeparator { get; set; }

        public InfoRow()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            BackColor = Color.Transparent;
            Font = UiTheme.FontUI(9F);
            ForeColor = UiTheme.TextSecondary;
            Height = 28;
            KeyText = "";
            _valueText = "—";
            ShowSeparator = true;
        }

        public void SetValue(string value)
        {
            _valueText = string.IsNullOrEmpty(value) ? "—" : value;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            TextFormatFlags leftFlags = TextFormatFlags.Left |
                                        TextFormatFlags.VerticalCenter |
                                        TextFormatFlags.NoPadding;
            TextFormatFlags rightFlags = TextFormatFlags.Right |
                                         TextFormatFlags.VerticalCenter |
                                         TextFormatFlags.NoPadding |
                                         TextFormatFlags.EndEllipsis;

            Rectangle keyRect = new Rectangle(0, 0, Width / 2, Height);
            Rectangle valueRect = new Rectangle(Width / 2, 0, Width - Width / 2, Height);

            TextRenderer.DrawText(e.Graphics, KeyText, Font, keyRect, UiTheme.TextSecondary, leftFlags);

            bool empty = _valueText == "—";
            Color valueColor = empty ? UiTheme.TextTertiary : UiTheme.Text;
            Font valueFont = empty ? Font : UiTheme.FontMono(9F);
            TextRenderer.DrawText(e.Graphics, _valueText, valueFont, valueRect, valueColor, rightFlags);

            if (ShowSeparator)
            {
                using (Pen pen = new Pen(Color.FromArgb(242, 242, 245), 1F))
                {
                    e.Graphics.DrawLine(pen, 0, Height - 1, Width, Height - 1);
                }
            }
        }
    }

    public class ChipToggle : Control
    {
        private bool _checked;
        private bool _hover;

        public event EventHandler CheckedChanged;

        public bool Checked
        {
            get { return _checked; }
            set
            {
                if (_checked == value) return;
                _checked = value;
                Invalidate();
                if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty);
            }
        }

        public ChipToggle()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.Selectable, true);
            DoubleBuffered = true;
            AutoSize = true;
            Height = 26;
            BackColor = UiTheme.Card;
            ForeColor = UiTheme.TextSecondary;
            Font = UiTheme.FontUI(8.5F);
            Cursor = Cursors.Hand;
            TabStop = true;
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            Size textSize = TextRenderer.MeasureText(Text, Font);
            return new Size(textSize.Width + 22, Math.Max(26, textSize.Height + 8));
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hover = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnClick(EventArgs e)
        {
            if (Enabled)
            {
                Checked = !Checked;
                Focus();
            }
            base.OnClick(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                Checked = !Checked;
                e.Handled = true;
            }
            base.OnKeyDown(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            Invalidate();
            base.OnEnabledChanged(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            Color fill;
            Color border;
            Color fore;

            if (!Enabled)
            {
                fill = BackColor;
                border = UiTheme.Border;
                fore = UiTheme.TextTertiary;
            }
            else if (_checked)
            {
                fill = UiTheme.PrimarySoft;
                border = Color.FromArgb(243, 199, 154);
                fore = UiTheme.Accent;
            }
            else
            {
                fill = _hover ? UiTheme.Blend(BackColor, Color.Black, 0.04) : BackColor;
                border = _hover ? UiTheme.BorderStrong : UiTheme.Border;
                fore = UiTheme.TextSecondary;
            }

            RectangleF rect = new RectangleF(0.5F, 0.5F, Width - 1F, Height - 1F);
            using (GraphicsPath path = UiTheme.RoundedRect(rect, Height / 2F))
            using (SolidBrush brush = new SolidBrush(fill))
            using (Pen pen = new Pen(border, 1F))
            {
                e.Graphics.FillPath(brush, path);
                e.Graphics.DrawPath(pen, path);
            }

            TextFormatFlags flags = TextFormatFlags.HorizontalCenter |
                                    TextFormatFlags.VerticalCenter |
                                    TextFormatFlags.NoPadding |
                                    TextFormatFlags.EndEllipsis;
            TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle, fore, flags);
        }
    }

    public class ToggleSwitch : Control
    {
        private bool _checked;
        private bool _hover;

        public event EventHandler CheckedChanged;

        public bool Checked
        {
            get { return _checked; }
            set
            {
                if (_checked == value) return;
                _checked = value;
                Invalidate();
                if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty);
            }
        }

        public ToggleSwitch()
        {
            SetStyle(ControlStyles.UserPaint |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw |
                     ControlStyles.Selectable, true);
            DoubleBuffered = true;
            Size = new Size(32, 19);
            BackColor = UiTheme.Card;
            Cursor = Cursors.Hand;
            TabStop = true;
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hover = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnClick(EventArgs e)
        {
            if (Enabled)
            {
                Checked = !Checked;
                Focus();
            }
            base.OnClick(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                Checked = !Checked;
                e.Handled = true;
            }
            base.OnKeyDown(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            Invalidate();
            base.OnEnabledChanged(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            float trackHeight = Height - 1F;
            RectangleF trackRect = new RectangleF(0.5F, 0.5F, Width - 1F, trackHeight);

            Color track;
            if (!Enabled)
            {
                track = Color.FromArgb(232, 232, 235);
            }
            else if (_checked)
            {
                track = _hover ? UiTheme.Accent : UiTheme.Primary;
            }
            else
            {
                track = _hover ? Color.FromArgb(198, 198, 204) : Color.FromArgb(210, 210, 216);
            }

            using (GraphicsPath path = UiTheme.RoundedRect(trackRect, trackHeight / 2F))
            using (SolidBrush brush = new SolidBrush(track))
            {
                e.Graphics.FillPath(brush, path);
            }

            float knobSize = Height - 5F;
            float knobX = _checked ? Width - knobSize - 2.5F : 2.5F;
            RectangleF knobRect = new RectangleF(knobX, 2.5F, knobSize, knobSize);
            using (SolidBrush knobBrush = new SolidBrush(Enabled ? Color.White : Color.FromArgb(246, 246, 248)))
            using (Pen knobPen = new Pen(Color.FromArgb(30, 0, 0, 0), 1F))
            {
                e.Graphics.FillEllipse(knobBrush, knobRect);
                e.Graphics.DrawEllipse(knobPen, knobRect);
            }
        }
    }
}
