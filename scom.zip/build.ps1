﻿$ErrorActionPreference = "Stop"

$root = $PSScriptRoot
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if (-not (Test-Path -LiteralPath $csc)) {
    $csc = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe"
}
if (-not (Test-Path -LiteralPath $csc)) {
    throw "Cannot find csc.exe (.NET Framework 4.x compiler)."
}

$out = Join-Path $root "Scom.exe"
$cscArgs = @(
    "/nologo",
    "/target:winexe",
    "/optimize+",
    "/codepage:65001",
    "/out:$out",
    "/r:System.dll",
    "/r:System.Core.dll",
    "/r:System.Drawing.dll",
    "/r:System.Windows.Forms.dll"
)

$icon = Join-Path $root "assets\app.ico"
if (Test-Path -LiteralPath $icon) {
    $cscArgs += "/win32icon:$icon"
}

$cscArgs += (Join-Path $root "src\Program.cs")
$cscArgs += (Join-Path $root "src\MainForm.cs")
$cscArgs += (Join-Path $root "src\W25QxxProgrammer.cs")
$cscArgs += (Join-Path $root "src\UiControls.cs")
$cscArgs += (Join-Path $root "src\W25QxxForm.cs")

& $csc $cscArgs
if ($LASTEXITCODE -ne 0) {
    throw "Build failed with exit code $LASTEXITCODE."
}

Write-Host "Build OK: $out"

