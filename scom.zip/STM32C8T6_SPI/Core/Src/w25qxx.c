#include "w25qxx.h"
#include "spi.h"

#include <stdio.h>

#define W25QXX_CMD_WRITE_ENABLE  0x06U
#define W25QXX_CMD_READ_STATUS1  0x05U
#define W25QXX_CMD_READ_DATA     0x03U
#define W25QXX_CMD_PAGE_PROGRAM  0x02U
#define W25QXX_CMD_SECTOR_ERASE  0x20U
#define W25QXX_CMD_BLOCK32_ERASE 0x52U
#define W25QXX_CMD_BLOCK64_ERASE 0xD8U
#define W25QXX_CMD_CHIP_ERASE    0xC7U
#define W25QXX_CMD_JEDEC_ID      0x9FU
#define W25QXX_CMD_RELEASE_PD    0xABU

#define W25QXX_STATUS_BUSY       0x01U
#define W25QXX_STATUS_WEL        0x02U

#define W25QXX_SPI_TIMEOUT       1000U

uint32_t g_w25qxx_jedec_id;
uint32_t g_w25qxx_capacity;
char g_w25qxx_model[16];

static void W25QXX_Select(void)
{
  HAL_GPIO_WritePin(W25QXX_CS_PORT, W25QXX_CS_PIN, GPIO_PIN_RESET);
}

static void W25QXX_Deselect(void)
{
  HAL_GPIO_WritePin(W25QXX_CS_PORT, W25QXX_CS_PIN, GPIO_PIN_SET);
}

static uint8_t W25QXX_Transfer(uint8_t data)
{
  uint8_t rx = 0xFFU;

  if (HAL_SPI_TransmitReceive(&hspi1, &data, &rx, 1U, W25QXX_SPI_TIMEOUT) != HAL_OK)
  {
    return 0xFFU;
  }

  return rx;
}

static void W25QXX_SendAddress(uint32_t addr)
{
  W25QXX_Transfer((uint8_t)(addr >> 16));
  W25QXX_Transfer((uint8_t)(addr >> 8));
  W25QXX_Transfer((uint8_t)addr);
}

static uint8_t W25QXX_ReadStatus1(void)
{
  uint8_t status;

  W25QXX_Select();
  W25QXX_Transfer(W25QXX_CMD_READ_STATUS1);
  status = W25QXX_Transfer(0xFFU);
  W25QXX_Deselect();

  return status;
}

static int W25QXX_WaitReady(uint32_t timeout_ms)
{
  uint32_t start = HAL_GetTick();

  while ((W25QXX_ReadStatus1() & W25QXX_STATUS_BUSY) != 0U)
  {
    if ((HAL_GetTick() - start) >= timeout_ms)
    {
      return -1;
    }
  }

  return 0;
}

static int W25QXX_WriteEnable(void)
{
  W25QXX_Select();
  W25QXX_Transfer(W25QXX_CMD_WRITE_ENABLE);
  W25QXX_Deselect();

  if ((W25QXX_ReadStatus1() & W25QXX_STATUS_WEL) == 0U)
  {
    return -1;
  }

  return 0;
}

static void W25QXX_WakeUp(void)
{
  W25QXX_Select();
  W25QXX_Transfer(W25QXX_CMD_RELEASE_PD);
  W25QXX_Deselect();
  HAL_Delay(1);
}

uint32_t W25QXX_ReadJedecId(void)
{
  uint8_t manufacturer;
  uint8_t memory_type;
  uint8_t capacity_code;

  W25QXX_Select();
  W25QXX_Transfer(W25QXX_CMD_JEDEC_ID);
  manufacturer = W25QXX_Transfer(0xFFU);
  memory_type = W25QXX_Transfer(0xFFU);
  capacity_code = W25QXX_Transfer(0xFFU);
  W25QXX_Deselect();

  return ((uint32_t)manufacturer << 16) |
         ((uint32_t)memory_type << 8) |
         (uint32_t)capacity_code;
}

static const char *W25QXX_VendorPrefix(uint8_t manufacturer)
{
  switch (manufacturer)
  {
    case 0xEF: return "W25Q";
    case 0xC8: return "GD25Q";
    case 0x85: return "P25Q";
    case 0x20: return "XM25Q";
    case 0x1C: return "EN25Q";
    case 0xBF: return "SST25";
    case 0x9D: return "IS25";
    case 0xA1: return "FM25Q";
    case 0x68: return "BY25Q";
    default:   return "SPI25Q";
  }
}

static void W25QXX_BuildInfo(uint32_t jedec_id)
{
  uint8_t manufacturer = (uint8_t)((jedec_id >> 16) & 0xFFU);
  uint8_t capacity_code = (uint8_t)(jedec_id & 0xFFU);
  uint32_t mbit;

  g_w25qxx_jedec_id = jedec_id;

  if (capacity_code < 31U)
  {
    g_w25qxx_capacity = 1UL << capacity_code;
  }
  else
  {
    g_w25qxx_capacity = 0;
  }

  if (g_w25qxx_capacity != 0U)
  {
    mbit = g_w25qxx_capacity / (128UL * 1024UL);
    if (mbit == 8U)
    {
      sprintf(g_w25qxx_model, "%s80", W25QXX_VendorPrefix(manufacturer));
    }
    else
    {
      sprintf(g_w25qxx_model, "%s%lu",
              W25QXX_VendorPrefix(manufacturer), (unsigned long)mbit);
    }
  }
  else
  {
    sprintf(g_w25qxx_model, "UNKNOWN");
  }
}

void W25QXX_Init(void)
{
  uint32_t jedec_id = 0;
  uint32_t attempt;

  W25QXX_Deselect();
  HAL_Delay(1);

  for (attempt = 0; attempt < 3U; attempt++)
  {
    W25QXX_WakeUp();
    jedec_id = W25QXX_ReadJedecId();
    if (jedec_id != 0U && jedec_id != 0xFFFFFFU)
    {
      break;
    }
    HAL_Delay(5);
  }

  W25QXX_BuildInfo(jedec_id);
}

int W25QXX_ReadData(uint32_t addr, uint8_t *buffer, uint32_t length)
{
  while (length > 0U)
  {
    uint16_t chunk = (length > 4096U) ? 4096U : (uint16_t)length;

    if ((g_w25qxx_capacity != 0U) &&
        ((addr >= g_w25qxx_capacity) || (length > (g_w25qxx_capacity - addr))))
    {
      return -1;
    }

    W25QXX_Select();
    W25QXX_Transfer(W25QXX_CMD_READ_DATA);
    W25QXX_SendAddress(addr);

    if (HAL_SPI_Receive(&hspi1, buffer, chunk, W25QXX_SPI_TIMEOUT) != HAL_OK)
    {
      W25QXX_Deselect();
      return -1;
    }

    W25QXX_Deselect();

    addr += chunk;
    buffer += chunk;
    length -= chunk;
  }

  return 0;
}

int W25QXX_WriteData(uint32_t addr, const uint8_t *buffer, uint32_t length)
{
  while (length > 0U)
  {
    uint32_t page_left = W25QXX_PAGE_SIZE - (addr & (W25QXX_PAGE_SIZE - 1U));
    uint16_t chunk = (length < page_left) ? (uint16_t)length : (uint16_t)page_left;

    if ((g_w25qxx_capacity != 0U) &&
        ((addr >= g_w25qxx_capacity) || (length > (g_w25qxx_capacity - addr))))
    {
      return -1;
    }

    if (W25QXX_WriteEnable() != 0)
    {
      return -1;
    }

    W25QXX_Select();
    W25QXX_Transfer(W25QXX_CMD_PAGE_PROGRAM);
    W25QXX_SendAddress(addr);

    if (HAL_SPI_Transmit(&hspi1, (uint8_t *)buffer, chunk, W25QXX_SPI_TIMEOUT) != HAL_OK)
    {
      W25QXX_Deselect();
      return -1;
    }

    W25QXX_Deselect();

    if (W25QXX_WaitReady(2000U) != 0)
    {
      return -1;
    }

    addr += chunk;
    buffer += chunk;
    length -= chunk;
  }

  return 0;
}

static int W25QXX_EraseCommand(uint8_t command, uint32_t addr, uint32_t timeout_ms)
{
  if (W25QXX_WriteEnable() != 0)
  {
    return -1;
  }

  W25QXX_Select();
  W25QXX_Transfer(command);
  if (command != W25QXX_CMD_CHIP_ERASE)
  {
    W25QXX_SendAddress(addr);
  }
  W25QXX_Deselect();

  return W25QXX_WaitReady(timeout_ms);
}

int W25QXX_EraseRange(uint32_t addr, uint32_t length)
{
  uint32_t end;

  if (length == 0U)
  {
    return 0;
  }

  if ((g_w25qxx_capacity != 0U) &&
      ((addr >= g_w25qxx_capacity) || (length > (g_w25qxx_capacity - addr))))
  {
    return -1;
  }

  end = addr + length;

  while (addr < end)
  {
    uint32_t remaining = end - addr;

    if (((addr & (W25QXX_BLOCK64_SIZE - 1U)) == 0U) && (remaining >= W25QXX_BLOCK64_SIZE))
    {
      if (W25QXX_EraseCommand(W25QXX_CMD_BLOCK64_ERASE, addr, 10000U) != 0)
      {
        return -1;
      }
      addr += W25QXX_BLOCK64_SIZE;
    }
    else if (((addr & (W25QXX_BLOCK32_SIZE - 1U)) == 0U) && (remaining >= W25QXX_BLOCK32_SIZE))
    {
      if (W25QXX_EraseCommand(W25QXX_CMD_BLOCK32_ERASE, addr, 5000U) != 0)
      {
        return -1;
      }
      addr += W25QXX_BLOCK32_SIZE;
    }
    else
    {
      uint32_t sector = addr & ~(W25QXX_SECTOR_SIZE - 1U);
      if (W25QXX_EraseCommand(W25QXX_CMD_SECTOR_ERASE, sector, 3000U) != 0)
      {
        return -1;
      }
      addr = sector + W25QXX_SECTOR_SIZE;
    }
  }

  return 0;
}

int W25QXX_EraseChip(void)
{
  return W25QXX_EraseCommand(W25QXX_CMD_CHIP_ERASE, 0U, 300000U);
}
