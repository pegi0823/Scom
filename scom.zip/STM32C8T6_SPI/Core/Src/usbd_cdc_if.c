#include "usbd_cdc_if.h"
#include "usb_device.h"
#include "usart.h"

#define APP_RX_DATA_SIZE 2048U

extern PCD_HandleTypeDef hpcd_USB_FS;

static uint8_t UserRxBufferFS[APP_RX_DATA_SIZE];
static uint8_t UserTxBufferFS[CDC_DATA_FS_OUT_PACKET_SIZE];
static volatile uint16_t cdc_rx_pending_len;
static volatile uint8_t cdc_rx_blocked;

static void CDC_AbortTx(USBD_CDC_HandleTypeDef *hcdc);

static int8_t CDC_Init_FS(void);
static int8_t CDC_DeInit_FS(void);
static int8_t CDC_Control_FS(uint8_t cmd, uint8_t *pbuf, uint16_t length);
static int8_t CDC_Receive_FS(uint8_t *Buf, uint32_t *Len);

USBD_CDC_ItfTypeDef USBD_Interface_fops_FS =
{
  CDC_Init_FS,
  CDC_DeInit_FS,
  CDC_Control_FS,
  CDC_Receive_FS
};

static int8_t CDC_Init_FS(void)
{
  USBD_CDC_SetTxBuffer(&hUsbDeviceFS, UserTxBufferFS, 0U);
  USBD_CDC_SetRxBuffer(&hUsbDeviceFS, UserRxBufferFS);
  return (int8_t)USBD_OK;
}

static int8_t CDC_DeInit_FS(void)
{
  cdc_rx_pending_len = 0U;
  cdc_rx_blocked = 0U;
  return (int8_t)USBD_OK;
}

static int8_t CDC_Control_FS(uint8_t cmd, uint8_t *pbuf, uint16_t length)
{
  (void)pbuf;
  (void)length;

  switch (cmd)
  {
    case CDC_SET_LINE_CODING:
    case CDC_GET_LINE_CODING:
    case CDC_SET_CONTROL_LINE_STATE:
    case CDC_SEND_BREAK:
      break;

    default:
      break;
  }

  return (int8_t)USBD_OK;
}

static int8_t CDC_Receive_FS(uint8_t *Buf, uint32_t *Len)
{
  uint16_t len = (uint16_t)*Len;

  cdc_rx_pending_len = len;

  if (UART_RxFree() >= len)
  {
    UART_RxPush(Buf, len);
    cdc_rx_pending_len = 0U;
  }

  if ((cdc_rx_pending_len == 0U) &&
      (UART_RxFree() >= CDC_DATA_FS_OUT_PACKET_SIZE))
  {
    USBD_CDC_SetRxBuffer(&hUsbDeviceFS, UserRxBufferFS);
    (void)USBD_CDC_ReceivePacket(&hUsbDeviceFS);
    cdc_rx_blocked = 0U;
  }
  else
  {
    cdc_rx_blocked = 1U;
  }

  return (int8_t)USBD_OK;
}

void CDC_RxPoll(void)
{
  if ((cdc_rx_pending_len == 0U) && (cdc_rx_blocked == 0U))
  {
    return;
  }

  NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);
  NVIC_DisableIRQ(USART1_IRQn);

  if ((cdc_rx_pending_len != 0U) &&
      (UART_RxFree() >= cdc_rx_pending_len))
  {
    UART_RxPush(UserRxBufferFS, cdc_rx_pending_len);
    cdc_rx_pending_len = 0U;
  }

  if ((cdc_rx_pending_len == 0U) && (cdc_rx_blocked != 0U) &&
      (CDC_IsReady() != 0U) &&
      (UART_RxFree() >= CDC_DATA_FS_OUT_PACKET_SIZE))
  {
    cdc_rx_blocked = 0U;
    (void)USBD_CDC_ReceivePacket(&hUsbDeviceFS);
  }

  NVIC_EnableIRQ(USART1_IRQn);
  NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);
}

uint8_t CDC_IsReady(void)
{
  if (hUsbDeviceFS.dev_state != USBD_STATE_CONFIGURED)
  {
    return 0U;
  }

  if (hUsbDeviceFS.pClassData == NULL)
  {
    return 0U;
  }

  return 1U;
}

uint8_t CDC_Transmit_FS(uint8_t *Buf, uint16_t Len)
{
  USBD_CDC_HandleTypeDef *hcdc;

  if (CDC_IsReady() == 0U)
  {
    return (uint8_t)USBD_FAIL;
  }

  hcdc = (USBD_CDC_HandleTypeDef *)hUsbDeviceFS.pClassData;
  if (hcdc->TxState != 0U)
  {
    return (uint8_t)USBD_BUSY;
  }

  if (USBD_CDC_SetTxBuffer(&hUsbDeviceFS, Buf, Len) != (uint8_t)USBD_OK)
  {
    return (uint8_t)USBD_FAIL;
  }

  return USBD_CDC_TransmitPacket(&hUsbDeviceFS);
}

static void CDC_AbortTx(USBD_CDC_HandleTypeDef *hcdc)
{
  NVIC_DisableIRQ(USB_LP_CAN1_RX0_IRQn);
  (void)HAL_PCD_EP_Abort(&hpcd_USB_FS, CDC_IN_EP);
  hUsbDeviceFS.ep_in[CDC_IN_EP & 0x0FU].total_length = 0U;
  hcdc->TxState = 0U;
  NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);
}

uint8_t CDC_Transmit_FS_Blocking(const uint8_t *Buf, uint16_t Len, uint32_t Timeout)
{
  USBD_CDC_HandleTypeDef *hcdc;
  uint32_t start;

  if (CDC_IsReady() == 0U)
  {
    return (uint8_t)USBD_FAIL;
  }

  hcdc = (USBD_CDC_HandleTypeDef *)hUsbDeviceFS.pClassData;

  start = HAL_GetTick();
  while (hcdc->TxState != 0U)
  {
    if ((HAL_GetTick() - start) >= Timeout)
    {
      CDC_AbortTx(hcdc);
      return (uint8_t)USBD_BUSY;
    }
  }

  if (USBD_CDC_SetTxBuffer(&hUsbDeviceFS, (uint8_t *)Buf, Len) != (uint8_t)USBD_OK)
  {
    return (uint8_t)USBD_FAIL;
  }

  if (USBD_CDC_TransmitPacket(&hUsbDeviceFS) != (uint8_t)USBD_OK)
  {
    return (uint8_t)USBD_BUSY;
  }

  start = HAL_GetTick();
  while (hcdc->TxState != 0U)
  {
    if ((HAL_GetTick() - start) >= Timeout)
    {
      CDC_AbortTx(hcdc);
      return (uint8_t)USBD_BUSY;
    }
  }

  return (uint8_t)USBD_OK;
}
