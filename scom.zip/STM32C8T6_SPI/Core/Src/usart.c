#include "usart.h"
#include "usbd_cdc_if.h"

#include <string.h>

#define UART_RX_BUFFER_SIZE 2048U
#define UART_BAUDRATE       115200U

static uint8_t rx_buffer[UART_RX_BUFFER_SIZE];
static volatile uint16_t rx_head;
static volatile uint16_t rx_tail;

void MX_USART1_UART_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  uint32_t pclk2;

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_USART1_CLK_ENABLE();

  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  USART1->CR1 = 0;
  USART1->CR2 = 0;
  USART1->CR3 = 0;

  pclk2 = HAL_RCC_GetPCLK2Freq();
  USART1->BRR = (pclk2 + (UART_BAUDRATE / 2U)) / UART_BAUDRATE;

  USART1->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE | USART_CR1_RXNEIE;

  HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(USART1_IRQn);
}

void USART1_IRQHandler(void)
{
  uint32_t status = USART1->SR;

  if ((status & (USART_SR_RXNE | USART_SR_ORE | USART_SR_NE |
                 USART_SR_FE | USART_SR_PE)) != 0U)
  {
    uint8_t data = (uint8_t)USART1->DR;

    if ((status & USART_SR_RXNE) != 0U)
    {
      uint16_t next = (uint16_t)((rx_head + 1U) & (UART_RX_BUFFER_SIZE - 1U));
      if (next != rx_tail)
      {
        rx_buffer[rx_head] = data;
        rx_head = next;
      }
    }
  }
}

void UART_RxPush(const uint8_t *data, uint16_t len)
{
  uint16_t i;

  for (i = 0; i < len; i++)
  {
    uint16_t next = (uint16_t)((rx_head + 1U) & (UART_RX_BUFFER_SIZE - 1U));
    if (next != rx_tail)
    {
      rx_buffer[rx_head] = data[i];
      rx_head = next;
    }
  }
}

void UART_Send(const uint8_t *data, uint16_t len)
{
  uint16_t i;

  if (CDC_IsReady() != 0U)
  {
    if (CDC_Transmit_FS_Blocking(data, len, 200U) == (uint8_t)USBD_OK)
    {
      return;
    }
  }

  for (i = 0; i < len; i++)
  {
    while ((USART1->SR & USART_SR_TXE) == 0U)
    {
    }
    USART1->DR = data[i];
  }

  while ((USART1->SR & USART_SR_TC) == 0U)
  {
  }
}

void UART_SendString(const char *text)
{
  UART_Send((const uint8_t *)text, (uint16_t)strlen(text));
}

uint16_t UART_RxFree(void)
{
  uint16_t head = rx_head;
  uint16_t tail = rx_tail;

  if (head >= tail)
  {
    return (uint16_t)((UART_RX_BUFFER_SIZE - 1U) - (head - tail));
  }

  return (uint16_t)((tail - head) - 1U);
}

int UART_RxPop(uint8_t *byte)
{
  CDC_RxPoll();

  if (rx_head == rx_tail)
  {
    return 0;
  }

  *byte = rx_buffer[rx_tail];
  rx_tail = (uint16_t)((rx_tail + 1U) & (UART_RX_BUFFER_SIZE - 1U));
  return 1;
}

int UART_RxWait(uint8_t *byte, uint32_t timeout_ms)
{
  uint32_t start = HAL_GetTick();

  while (UART_RxPop(byte) == 0)
  {
    if ((HAL_GetTick() - start) >= timeout_ms)
    {
      return 0;
    }
  }

  return 1;
}

void UART_FlushRx(void)
{
  rx_tail = rx_head;
}
