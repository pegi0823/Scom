#include "w25qxx_cmd.h"
#include "w25qxx.h"
#include "usart.h"

#include <stdio.h>
#include <string.h>

#define CMD_LINE_SIZE   96U
#define CMD_PAGE_BUFFER 256U
#define CMD_READ_BUFFER 1024U

static char cmd_line[CMD_LINE_SIZE];
static uint16_t cmd_length;
static uint8_t cmd_discard;

static uint8_t page_buffer[CMD_PAGE_BUFFER];
static uint8_t read_buffer[CMD_READ_BUFFER];

static int CMD_ParseU32(const char **text, uint32_t *value)
{
  const char *p = *text;
  uint32_t base = 10U;
  uint32_t result = 0U;
  int digits = 0;

  while ((*p == ' ') || (*p == '\t'))
  {
    p++;
  }

  if ((p[0] == '0') && ((p[1] == 'x') || (p[1] == 'X')))
  {
    base = 16U;
    p += 2;
  }

  while (*p != '\0')
  {
    uint32_t digit;

    if ((*p >= '0') && (*p <= '9'))
    {
      digit = (uint32_t)(*p - '0');
    }
    else if ((base == 16U) && (*p >= 'a') && (*p <= 'f'))
    {
      digit = (uint32_t)(*p - 'a') + 10U;
    }
    else if ((base == 16U) && (*p >= 'A') && (*p <= 'F'))
    {
      digit = (uint32_t)(*p - 'A') + 10U;
    }
    else
    {
      break;
    }

    if (digit >= base)
    {
      break;
    }

    result = (result * base) + digit;
    digits++;
    p++;
  }

  if (digits == 0)
  {
    return 0;
  }

  *text = p;
  *value = result;
  return 1;
}

static int CMD_ReadExact(uint8_t *buffer, uint16_t length)
{
  while (length > 0U)
  {
    if (UART_RxWait(buffer, 2000U) == 0)
    {
      return -1;
    }
    buffer++;
    length--;
  }

  return 0;
}

static int CMD_RangeValid(uint32_t addr, uint32_t length)
{
  if (g_w25qxx_capacity == 0U)
  {
    return 1;
  }

  if (addr >= g_w25qxx_capacity)
  {
    return 0;
  }

  return (length <= (g_w25qxx_capacity - addr));
}

static void CMD_HandleId(void)
{
  char response[64];

  if ((g_w25qxx_jedec_id == 0U) || (g_w25qxx_jedec_id == 0xFFFFFFU))
  {
    W25QXX_Init();
  }

  if ((g_w25qxx_jedec_id == 0U) || (g_w25qxx_jedec_id == 0xFFFFFFU))
  {
    UART_SendString("ERR,NOFLASH\r\n");
    return;
  }

  sprintf(response, "OK,%06lX,%lu,%s\r\n",
          (unsigned long)g_w25qxx_jedec_id,
          (unsigned long)g_w25qxx_capacity,
          g_w25qxx_model);
  UART_SendString(response);
}

static void CMD_HandleEraseRange(const char *params)
{
  uint32_t addr;
  uint32_t length;

  if ((CMD_ParseU32(&params, &addr) == 0) || (CMD_ParseU32(&params, &length) == 0))
  {
    UART_SendString("ERR,PARAM\r\n");
    return;
  }

  if (CMD_RangeValid(addr, length) == 0)
  {
    UART_SendString("ERR,RANGE\r\n");
    return;
  }

  if (W25QXX_EraseRange(addr, length) != 0)
  {
    UART_SendString("ERR,ERASE\r\n");
    return;
  }

  UART_SendString("OK,ERASED\r\n");
}

static void CMD_HandleEraseChip(void)
{
  if (W25QXX_EraseChip() != 0)
  {
    UART_SendString("ERR,ERASE\r\n");
    return;
  }

  UART_SendString("OK,ERASED\r\n");
}

static void CMD_HandleWrite(const char *params)
{
  uint32_t addr;
  uint32_t length;
  uint32_t remaining;
  char response[48];

  if ((CMD_ParseU32(&params, &addr) == 0) || (CMD_ParseU32(&params, &length) == 0))
  {
    UART_SendString("ERR,PARAM\r\n");
    return;
  }

  if (CMD_RangeValid(addr, length) == 0)
  {
    UART_SendString("ERR,RANGE\r\n");
    return;
  }

  UART_SendString("OK,READY\r\n");

  remaining = length;

  while (remaining > 0U)
  {
    uint32_t page_left = W25QXX_PAGE_SIZE - (addr & (W25QXX_PAGE_SIZE - 1U));
    uint16_t chunk = (remaining < page_left) ? (uint16_t)remaining : (uint16_t)page_left;

    if (CMD_ReadExact(page_buffer, chunk) != 0)
    {
      UART_SendString("ERR,RX\r\n");
      return;
    }

    if (W25QXX_WriteData(addr, page_buffer, chunk) != 0)
    {
      UART_SendString("ERR,WRITE\r\n");
      return;
    }

    addr += chunk;
    remaining -= chunk;
  }

  sprintf(response, "OK,WROTE %lu\r\n", (unsigned long)length);
  UART_SendString(response);
}

static void CMD_HandleRead(const char *params)
{
  uint32_t addr;
  uint32_t length;
  uint32_t remaining;
  char response[48];

  if ((CMD_ParseU32(&params, &addr) == 0) || (CMD_ParseU32(&params, &length) == 0))
  {
    UART_SendString("ERR,PARAM\r\n");
    return;
  }

  if (CMD_RangeValid(addr, length) == 0)
  {
    UART_SendString("ERR,RANGE\r\n");
    return;
  }

  remaining = length;

  while (remaining > 0U)
  {
    uint16_t chunk = (remaining > CMD_READ_BUFFER) ? (uint16_t)CMD_READ_BUFFER : (uint16_t)remaining;

    if (W25QXX_ReadData(addr, read_buffer, chunk) != 0)
    {
      UART_SendString("ERR,READ\r\n");
      return;
    }

    UART_Send(read_buffer, chunk);

    addr += chunk;
    remaining -= chunk;
  }

  sprintf(response, "OK,READ %lu\r\n", (unsigned long)length);
  UART_SendString(response);
}

static void CMD_HandleLine(char *line)
{
  char command;

  while ((*line != '\0') &&
         (((*line < 'A') || (*line > 'Z')) &&
          ((*line < 'a') || (*line > 'z'))))
  {
    line++;
  }

  command = *line;
  if (command == '\0')
  {
    return;
  }

  if ((command >= 'a') && (command <= 'z'))
  {
    command = (char)(command - 'a' + 'A');
  }

  line++;

  switch (command)
  {
    case 'I':
      CMD_HandleId();
      break;

    case 'S':
      CMD_HandleEraseRange(line);
      break;

    case 'E':
      CMD_HandleEraseChip();
      break;

    case 'W':
      CMD_HandleWrite(line);
      break;

    case 'R':
      CMD_HandleRead(line);
      break;

    default:
      UART_SendString("ERR,CMD\r\n");
      break;
  }
}

void W25QXX_CMD_Init(void)
{
  cmd_length = 0U;
  cmd_discard = 0U;
  W25QXX_Init();
}

void W25QXX_CMD_Poll(void)
{
  uint8_t ch;

  while (UART_RxPop(&ch) != 0)
  {
    if (ch == '\r')
    {
      continue;
    }

    if (ch == '\n')
    {
      if ((cmd_discard == 0U) && (cmd_length > 0U))
      {
        cmd_line[cmd_length] = '\0';
        CMD_HandleLine(cmd_line);
      }
      cmd_length = 0U;
      cmd_discard = 0U;
      continue;
    }

    if (cmd_discard != 0U)
    {
      continue;
    }

    if (cmd_length < (CMD_LINE_SIZE - 1U))
    {
      cmd_line[cmd_length++] = (char)ch;
    }
    else
    {
      cmd_length = 0U;
      cmd_discard = 1U;
    }
  }
}
