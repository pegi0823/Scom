#ifndef __W25QXX_CMD_H__
#define __W25QXX_CMD_H__

#ifdef __cplusplus
extern "C" {
#endif

void W25QXX_CMD_Init(void);
void W25QXX_CMD_Poll(void);

#ifdef __cplusplus
}
#endif

#endif
