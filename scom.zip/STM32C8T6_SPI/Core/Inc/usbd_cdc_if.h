#ifndef __USBD_CDC_IF_H
#define __USBD_CDC_IF_H

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_cdc.h"

extern USBD_CDC_ItfTypeDef USBD_Interface_fops_FS;

uint8_t CDC_Transmit_FS(uint8_t *Buf, uint16_t Len);
uint8_t CDC_Transmit_FS_Blocking(const uint8_t *Buf, uint16_t Len, uint32_t Timeout);
uint8_t CDC_IsReady(void);
void CDC_RxPoll(void);

#ifdef __cplusplus
}
#endif

#endif
