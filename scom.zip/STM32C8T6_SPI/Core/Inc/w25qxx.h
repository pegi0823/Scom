#ifndef __W25QXX_H__
#define __W25QXX_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

#define W25QXX_CS_PORT GPIOA
#define W25QXX_CS_PIN  GPIO_PIN_4

#define W25QXX_PAGE_SIZE    256U
#define W25QXX_SECTOR_SIZE  4096U
#define W25QXX_BLOCK32_SIZE 32768U
#define W25QXX_BLOCK64_SIZE 65536U

extern uint32_t g_w25qxx_jedec_id;
extern uint32_t g_w25qxx_capacity;
extern char g_w25qxx_model[16];

void W25QXX_Init(void);
uint32_t W25QXX_ReadJedecId(void);
int W25QXX_ReadData(uint32_t addr, uint8_t *buffer, uint32_t length);
int W25QXX_WriteData(uint32_t addr, const uint8_t *buffer, uint32_t length);
int W25QXX_EraseRange(uint32_t addr, uint32_t length);
int W25QXX_EraseChip(void);

#ifdef __cplusplus
}
#endif

#endif
