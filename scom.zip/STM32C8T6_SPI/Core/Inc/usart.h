#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

void MX_USART1_UART_Init(void);
void UART_Send(const uint8_t *data, uint16_t len);
void UART_SendString(const char *text);
void UART_RxPush(const uint8_t *data, uint16_t len);
uint16_t UART_RxFree(void);
int UART_RxPop(uint8_t *byte);
int UART_RxWait(uint8_t *byte, uint32_t timeout_ms);
void UART_FlushRx(void);

#ifdef __cplusplus
}
#endif

#endif
