stm32c8t6_spi\startup_stm32f103xb.o: startup_stm32f103xb.s
